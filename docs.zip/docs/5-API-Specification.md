# 5. API Specification
## Backend API Reference for EZProject

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026
> **Status:** Planned for Backend Phase
> **Note:** Dự án hiện tại là Frontend-only (mock data). Tài liệu này mô tả API cho backend phase tiếp theo.

---

## 5.1. API Conventions

### Base URL
```
http://localhost:3000/api/v1
```

### Authentication
Tất cả các endpoint (ngoại trừ `/auth/*`) yêu cầu Bearer Token trong header:
```
Authorization: Bearer <access_token>
```

### Response Format
Tất cả responses tuân theo format chuẩn:

**Success (2xx):**
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation successful"
}
```

**Error (4xx/5xx):**
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Title is required",
    "field": "title"
  }
}
```

### HTTP Status Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 204 | No Content (successful delete) |
| 400 | Bad Request (validation error) |
| 401 | Unauthorized (not logged in) |
| 403 | Forbidden (no permission) |
| 404 | Not Found |
| 409 | Conflict |
| 500 | Internal Server Error |

### Pagination
```
GET /api/v1/projects?page=1&limit=10
```
Response:
```json
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 42,
    "totalPages": 5
  }
}
```

---

## 5.2. Authentication Endpoints

### 5.2.1. POST /auth/login

Đăng nhập.

**Request:**
```json
{
  "username": "user123",
  "password": "123"
}
```

**Response 200:**
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "uuid-xxx",
      "email": "khoa@demo.com",
      "username": "user123",
      "full_name": "Nguyễn Minh Khoa",
      "avatar": "https://...",
      "language": "vi",
      "theme": "light"
    },
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Errors:**
- `401 INVALID_CREDENTIALS` — Username hoặc password sai

---

### 5.2.2. POST /auth/register

Đăng ký tài khoản mới.

**Request:**
```json
{
  "full_name": "Nguyễn Văn A",
  "email": "nguyenvana@email.com",
  "username": "nguyenvana",
  "password": "securePassword123",
  "confirm_password": "securePassword123"
}
```

**Response 201:**
```json
{
  "success": true,
  "data": {
    "user": { ... },
    "access_token": "...",
    "refresh_token": "..."
  },
  "message": "Registration successful"
}
```

**Errors:**
- `400 VALIDATION_ERROR` — Email không hợp lệ
- `409 CONFLICT` — Username hoặc email đã tồn tại

---

### 5.2.3. POST /auth/refresh

Làm mới access token.

**Request:**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response 200:**
```json
{
  "success": true,
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "expires_in": 900
  }
}
```

---

### 5.2.4. POST /auth/logout

Đăng xuất.

**Request:**
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response 200:**
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

---

## 5.3. User / Profile Endpoints

### 5.3.1. GET /users/me

Lấy thông tin user hiện tại.

**Response 200:**
```json
{
  "success": true,
  "data": {
    "id": "uuid-xxx",
    "email": "khoa@demo.com",
    "username": "user123",
    "full_name": "Nguyễn Minh Khoa",
    "avatar": "https://...",
    "phone": "0123456789",
    "department": "CNTT",
    "position": "Sinh viên",
    "bio": "...",
    "language": "vi",
    "theme": "light",
    "created_at": "2026-01-01T00:00:00Z"
  }
}
```

---

### 5.3.2. PUT /users/me

Cập nhật thông tin user hiện tại.

**Request:**
```json
{
  "full_name": "Nguyễn Minh Khoa Updated",
  "phone": "0987654321",
  "department": "Khoa học Máy tính",
  "bio": "Sinh viên năm 3"
}
```

**Response 200:**
```json
{
  "success": true,
  "data": { ... },
  "message": "Profile updated"
}
```

---

### 5.3.3. PUT /users/me/preferences

Cập nhật preferences (theme, language).

**Request:**
```json
{
  "theme": "dark",
  "language": "en"
}
```

**Response 200:**
```json
{
  "success": true,
  "message": "Preferences updated"
}
```

---

### 5.3.4. PUT /users/me/password

Đổi mật khẩu.

**Request:**
```json
{
  "current_password": "oldPassword",
  "new_password": "newSecurePassword",
  "confirm_password": "newSecurePassword"
}
```

**Response 200:**
```json
{
  "success": true,
  "message": "Password changed successfully"
}
```

---

## 5.4. Project Endpoints

### 5.4.1. GET /projects

Lấy danh sách project của user.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `status` | string | Filter: active, completed, archived |
| `search` | string | Search by name |
| `page` | number | Page number |
| `limit` | number | Items per page |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "proj-1",
      "name": "Đồ án môn Lập trình Web",
      "description": "Xây dựng ứng dụng full-stack...",
      "subject": "Lập trình Web",
      "status": "active",
      "progress": 58,
      "deadline": "2026-06-16T23:59:59Z",
      "totalTasks": 15,
      "completedTasks": 7,
      "members": [
        {
          "user": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "avatar": "..." },
          "role": "leader",
          "isOwner": true
        }
      ],
      "createdAt": "2025-09-05T00:00:00Z"
    }
  ],
  "pagination": { "page": 1, "limit": 10, "total": 4, "totalPages": 1 }
}
```

---

### 5.4.2. POST /projects

Tạo project mới.

**Request:**
```json
{
  "name": "Đồ án Marketing",
  "description": "Chiến lược marketing cho sản phẩm mới",
  "subject": "Marketing căn bản",
  "deadline": "2026-07-01T23:59:59Z",
  "members": [
    { "userId": "uuid-xxx", "role": "supervisor" },
    { "userId": "uuid-yyy", "role": "member" }
  ]
}
```

**Response 201:**
```json
{
  "success": true,
  "data": { ... },
  "message": "Project created"
}
```

**Errors:**
- `400 VALIDATION_ERROR` — name is required
- `403 FORBIDDEN` — Cannot add members (leader only)

---

### 5.4.3. GET /projects/:id

Lấy chi tiết project.

**Response 200:**
```json
{
  "success": true,
  "data": {
    "id": "proj-1",
    "name": "Đồ án môn Lập trình Web",
    "description": "...",
    "subject": "Lập trình Web",
    "status": "active",
    "progress": 58,
    "deadline": "2026-06-16T23:59:59Z",
    "owner": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa" },
    "members": [...],
    "stats": {
      "totalTasks": 15,
      "completedTasks": 7,
      "totalDocuments": 6,
      "totalMeetings": 4
    },
    "createdAt": "2025-09-05T00:00:00Z"
  }
}
```

---

### 5.4.4. PUT /projects/:id

Cập nhật project.

**Request:**
```json
{
  "name": "Đồ án Lập trình Web (Updated)",
  "description": "...",
  "deadline": "2026-07-01T23:59:59Z",
  "status": "completed"
}
```

---

### 5.4.5. DELETE /projects/:id

Xóa project. **Chỉ owner mới có quyền.**

**Response 204:** No Content

---

### 5.4.6. PUT /projects/:id/progress

Cập nhật tiến độ project (tự động tính từ tasks).

**Response 200:**
```json
{
  "success": true,
  "data": { "progress": 62 }
}
```

---

## 5.5. Task Endpoints

### 5.5.1. GET /projects/:projectId/tasks

Lấy danh sách task của project.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `status` | string | Filter by status |
| `priority` | string | Filter by priority |
| `assigneeId` | string | Filter by assignee |
| `overdue` | boolean | Show only overdue |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "task-1",
      "projectId": "proj-1",
      "title": "Thiết lập lược đồ cơ sở dữ liệu",
      "description": "Tạo lược đồ PostgreSQL...",
      "status": "DONE",
      "priority": "HIGH",
      "assignee": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "avatar": "..." },
      "deadline": "2026-02-01T23:59:59Z",
      "commentsCount": 1,
      "createdAt": "2026-01-16T09:00:00Z"
    }
  ]
}
```

---

### 5.5.2. POST /projects/:projectId/tasks

Tạo task mới.

**Request:**
```json
{
  "title": "Thiết kế API",
  "description": "Thiết kế cấu trúc REST API...",
  "priority": "HIGH",
  "assigneeId": "mem-2",
  "deadline": "2026-06-01T23:59:59Z"
}
```

**Response 201:**
```json
{
  "success": true,
  "data": { "id": "task-new-1", ... },
  "message": "Task created"
}
```

---

### 5.5.3. GET /projects/:projectId/tasks/:taskId

Lấy chi tiết task.

**Response 200:**
```json
{
  "success": true,
  "data": {
    "id": "task-1",
    "projectId": "proj-1",
    "title": "Thiết lập lược đồ cơ sở dữ liệu",
    "description": "...",
    "status": "DONE",
    "priority": "HIGH",
    "assignee": { ... },
    "creator": { ... },
    "deadline": "2026-02-01T23:59:59Z",
    "requestType": null,
    "requestNote": null,
    "comments": [
      {
        "id": "c1",
        "content": "Đã hoàn thành...",
        "author": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa" },
        "createdAt": "2026-01-28T16:00:00Z"
      }
    ],
    "createdAt": "2026-01-16T09:00:00Z"
  }
}
```

---

### 5.5.4. PUT /projects/:projectId/tasks/:taskId

Cập nhật task.

**Request:**
```json
{
  "title": "Thiết kế API (Updated)",
  "description": "...",
  "status": "IN_PROGRESS",
  "priority": "HIGH",
  "assigneeId": "mem-3",
  "deadline": "2026-06-15T23:59:59Z"
}
```

---

### 5.5.5. DELETE /projects/:projectId/tasks/:taskId

Xóa task. **Chỉ leader/supervisor hoặc creator mới có quyền.**

**Response 204:** No Content

---

### 5.5.6. PUT /projects/:projectId/tasks/:taskId/comments

Thêm bình luận vào task.

**Request:**
```json
{
  "content": "Đã cập nhật theo yêu cầu!",
  "mentions": ["mem-2", "mem-3"]
}
```

**Response 201:**
```json
{
  "success": true,
  "data": { "id": "comment-new", ... },
  "message": "Comment added"
}
```

---

## 5.6. Document Endpoints

### 5.6.1. GET /projects/:projectId/documents

Lấy danh sách tài liệu.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `folderId` | string | Filter by folder (null for root) |
| `search` | string | Search by name |
| `fileType` | string | Filter by type |

**Response 200:**
```json
{
  "success": true,
  "data": {
    "folders": [
      { "id": "f1", "name": "Tài liệu tham khảo", "fileCount": 3 }
    ],
    "files": [
      {
        "id": "doc-1",
        "name": "Báo cáo tiến độ Sprint 1.docx",
        "fileType": "DOC",
        "size": "64 KB",
        "uploadedBy": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa" },
        "uploadDate": "2026-03-10T09:00:00Z",
        "fileUrl": "/uploads/doc-1.docx"
      }
    ]
  }
}
```

---

### 5.6.2. POST /projects/:projectId/documents/upload

Upload file. **Content-Type: multipart/form-data**

**Form Fields:**
| Field | Type | Description |
|-------|------|-------------|
| `file` | File | File binary |
| `folderId` | string | Optional folder ID |
| `name` | string | Optional custom name |

**Response 201:**
```json
{
  "success": true,
  "data": {
    "id": "doc-new",
    "name": "Báo cáo.docx",
    "fileType": "DOC",
    "size": "1.2 MB",
    "fileUrl": "/uploads/doc-new.docx",
    "uploadedBy": { ... },
    "uploadDate": "2026-05-29T00:00:00Z"
  },
  "message": "File uploaded"
}
```

---

### 5.6.3. GET /projects/:projectId/documents/:docId/download

Download file.

**Response:** Binary file stream (Content-Type: appropriate mime type)

---

### 5.6.4. PUT /projects/:projectId/documents/:docId

Cập nhật tài liệu (rename).

**Request:**
```json
{
  "name": "Báo cáo Sprint 2.docx"
}
```

---

### 5.6.5. DELETE /projects/:projectId/documents/:docId

Xóa tài liệu.

**Response 204:** No Content

---

### 5.6.6. POST /projects/:projectId/folders

Tạo thư mục.

**Request:**
```json
{
  "name": "Tài liệu tham khảo",
  "parentId": null
}
```

---

### 5.6.7. PUT /projects/:projectId/folders/:folderId

Đổi tên thư mục.

### 5.6.8. DELETE /projects/:projectId/folders/:folderId

Xóa thư mục và toàn bộ file bên trong.

---

## 5.7. Meeting Endpoints

### 5.7.1. GET /projects/:projectId/meetings

Lấy danh sách cuộc họp.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `status` | string | Filter: scheduled, in_progress, completed, cancelled |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "meet-1",
      "title": "Sprint Planning — tuần mới",
      "description": "Phân chia task và ưu tiên",
      "type": "online",
      "startTime": "2026-05-29T14:00:00Z",
      "endTime": "2026-05-29T15:30:00Z",
      "meetingLink": "https://meet.google.com/abc-defg-hij",
      "location": null,
      "status": "scheduled",
      "organizer": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa" },
      "attendees": [
        { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "willAttend": true },
        { "id": "mem-2", "full_name": "Trần Thị Linh", "willAttend": true },
        { "id": "mem-3", "full_name": "Lê Hoàng Huy", "willAttend": false, "declineReason": "Có lịch thi" }
      ],
      "createdAt": "2026-05-26T00:00:00Z"
    }
  ]
}
```

---

### 5.7.2. POST /projects/:projectId/meetings

Tạo cuộc họp.

**Request:**
```json
{
  "title": "Sprint Planning — tuần mới",
  "description": "Phân chia task và ưu tiên cho sprint",
  "type": "online",
  "startTime": "2026-05-29T14:00:00Z",
  "endTime": "2026-05-29T15:30:00Z",
  "meetingLink": "https://meet.google.com/abc-defg-hij",
  "location": null,
  "attendeeIds": ["mem-1", "mem-2", "mem-3"]
}
```

**Response 201:** `{ "success": true, "data": { ... }, "message": "Meeting created" }`

---

### 5.7.3. PUT /projects/:projectId/meetings/:meetingId

Cập nhật cuộc họp.

---

### 5.7.4. DELETE /projects/:projectId/meetings/:meetingId

Xóa cuộc họp. **Chỉ organizer mới có quyền.**

**Response 204:** No Content

---

### 5.7.5. PUT /projects/:projectId/meetings/:meetingId/rsvp

Phản hồi RSVP.

**Request:**
```json
{
  "willAttend": false,
  "declineReason": "Có lịch thi giữa kỳ"
}
```

---

## 5.8. Chat Endpoints

### 5.8.1. GET /projects/:projectId/chat/rooms

Lấy danh sách phòng chat.

**Response 200:**
```json
{
  "success": true,
  "data": {
    "general": { "id": "room-general-proj-1", "name": "General", "type": "general" },
    "channels": [
      { "id": "room-frontend", "name": "Frontend Team", "type": "channel" }
    ],
    "direct": [
      { "id": "dm-bob", "name": "Bob Chen", "type": "direct" }
    ]
  }
}
```

---

### 5.8.2. GET /projects/:projectId/chat/rooms/:roomId/messages

Lấy tin nhắn của một phòng. **Hỗ trợ cursor-based pagination.**

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `before` | string | Message ID (get messages before this) |
| `limit` | number | Default 50 |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "msg-1",
      "sender": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "avatar": "..." },
      "content": "Hey team! How is everyone progressing?",
      "timestamp": "2026-03-02T09:15:00Z",
      "channel": "group"
    }
  ],
  "pagination": {
    "hasMore": true,
    "nextCursor": "msg-50"
  }
}
```

---

### 5.8.3. POST /projects/:projectId/chat/rooms/:roomId/messages

Gửi tin nhắn.

**Request:**
```json
{
  "content": "I finished the API endpoints!",
  "channel": "group",
  "targetId": null
}
```

**Response 201:**
```json
{
  "success": true,
  "data": { "id": "msg-new", ... }
}
```

---

### 5.8.4. POST /projects/:projectId/chat/rooms

Tạo kênh mới.

**Request:**
```json
{
  "name": "Backend Team",
  "memberIds": ["mem-1", "mem-2"]
}
```

---

### 5.8.5. WebSocket: /chat

Kênh real-time cho tin nhắn mới.

**Event `new_message`:**
```json
{
  "event": "new_message",
  "data": {
    "roomId": "room-frontend",
    "message": { ... }
  }
}
```

---

## 5.9. Member Endpoints

### 5.9.1. GET /projects/:projectId/members

Lấy danh sách thành viên.

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "user": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "email": "khoa@demo.com", "avatar": "..." },
      "role": "leader",
      "isOwner": true,
      "tasksAssigned": 3,
      "tasksCompleted": 8
    }
  ]
}
```

---

### 5.9.2. POST /projects/:projectId/members/invite

Tạo link mời.

**Response 200:**
```json
{
  "success": true,
  "data": {
    "inviteLink": "https://ezproject.app/join/abc123xyz",
    "expiresAt": "2026-06-05T00:00:00Z"
  }
}
```

---

### 5.9.3. POST /projects/:projectId/members/join

Tham gia project qua invite link.

**Request:**
```json
{
  "inviteToken": "abc123xyz"
}
```

---

### 5.9.4. PUT /projects/:projectId/members/:userId/role

Cập nhật vai trò thành viên. **Chỉ leader mới có quyền.**

**Request:**
```json
{
  "role": "supervisor"
}
```

---

### 5.9.5. DELETE /projects/:projectId/members/:userId

Xóa thành viên khỏi project. **Chỉ leader mới có quyền.**

**Response 204:** No Content

---

## 5.10. Performance Endpoints

### 5.10.1. GET /projects/:projectId/performance

Lấy dữ liệu hiệu suất của tất cả thành viên.

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "member": { "id": "mem-1", "full_name": "Nguyễn Minh Khoa", "avatar": "..." },
      "tasksCompleted": 8,
      "tasksInProgress": 2,
      "tasksTodo": 1,
      "documentsUploaded": 4,
      "commentsCount": 15,
      "score": 92,
      "contributions": [
        { "date": "2026-03-01", "count": 3 },
        { "date": "2026-03-02", "count": 5 }
      ],
      "evaluation": {
        "rating": 5,
        "feedback": "Rất chăm chỉ và có trách nhiệm",
        "evaluatedAt": "2026-05-01T00:00:00Z"
      }
    }
  ]
}
```

---

### 5.10.2. POST /projects/:projectId/performance/evaluate

Đánh giá thành viên. **Chỉ leader/supervisor mới có quyền.**

**Request:**
```json
{
  "memberId": "mem-3",
  "rating": 4,
  "feedback": "Cần cải thiện tốc độ hoàn thành task"
}
```

**Response 200:**
```json
{
  "success": true,
  "message": "Evaluation submitted"
}
```

---

## 5.11. Activity & Notification Endpoints

### 5.11.1. GET /projects/:projectId/activities

Lấy feed hoạt động.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `limit` | number | Default 20 |
| `before` | string | Cursor for pagination |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "act-1",
      "user": { "id": "mem-2", "full_name": "Trần Thị Linh", "avatar": "..." },
      "action": "uploaded a document",
      "target": "Báo cáo tiến độ tuần 8.pdf",
      "targetType": "document",
      "targetId": "doc-1",
      "timestamp": "2026-05-28T09:30:00Z"
    }
  ]
}
```

---

### 5.11.2. GET /users/me/notifications

Lấy notifications của user.

**Query Params:**
| Param | Type | Description |
|-------|------|-------------|
| `unreadOnly` | boolean | Default false |

**Response 200:**
```json
{
  "success": true,
  "data": [
    {
      "id": "n1",
      "type": "task",
      "title": "Task được giao cho bạn",
      "body": "「Thiết kế UI」đã được gán cho bạn",
      "read": false,
      "link": "/projects/proj-1/tasks",
      "createdAt": "2026-05-29T10:00:00Z"
    }
  ],
  "unreadCount": 3
}
```

---

### 5.11.3. PUT /users/me/notifications/:id/read

Đánh dấu notification là đã đọc.

### 5.11.4. PUT /users/me/notifications/read-all

Đánh dấu tất cả notification là đã đọc.

---

## 5.12. Error Codes Reference

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `VALIDATION_ERROR` | 400 | Dữ liệu đầu vào không hợp lệ |
| `UNAUTHORIZED` | 401 | Chưa đăng nhập hoặc token hết hạn |
| `FORBIDDEN` | 403 | Không có quyền thực hiện hành động này |
| `NOT_FOUND` | 404 | Resource không tồn tại |
| `CONFLICT` | 409 | Resource đã tồn tại (duplicate) |
| `INTERNAL_ERROR` | 500 | Lỗi server nội bộ |
| `RATE_LIMITED` | 429 | Quá nhiều request |
