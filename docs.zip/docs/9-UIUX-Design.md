# 9. UI/UX Design
## Design System & Interface Specification

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 9.1. Design Philosophy

EZProject tuân thủ triết lý thiết kế **Tối giản & Tập trung** (Simplicity & Focus), nhằm giải quyết ba pain points chính của sinh viên: Communication Chaos, Methodology Gap, và Tool Complexity.

### 9.1.1. Core Design Principles

| Principle | Implementation |
|-----------|---------------|
| **Minimal cognitive load** | Mỗi trang chỉ hiển thị thông tin cần thiết; các tính năng nâng cao ẩn sau click |
| **Instant clarity** | Trạng thái rõ ràng qua màu sắc, icons, và layout — "Ai làm gì, deadline khi nào" visible ngay |
| **Zero learning curve** | Giao diện quen thuộc, icon-driven navigation, tooltip hỗ trợ |
| **Mobile-first (responsive)** | Thiết kế responsive cho màn hình từ 320px trở lên |

---

## 9.2. Design System

### 9.2.1. Color Palette

#### Light Mode

| Token | Hex | Usage |
|-------|-----|-------|
| **Primary** | `#2563EB` (Blue 600) | Buttons, links, active states |
| **Primary Hover** | `#1D4ED8` (Blue 700) | Button hover |
| **Accent** | `#7C3AED` (Violet 600) | Special highlights, AI features |
| **Success** | `#16A34A` (Green 600) | Done status, positive feedback |
| **Warning** | `#D97706` (Amber 600) | Medium priority, warnings |
| **Danger** | `#DC2626` (Red 600) | High priority, errors, delete |
| **Background** | `#FFFFFF` | Main background |
| **Surface** | `#F8FAFC` (Slate 50) | Cards, sidebars |
| **Surface Hover** | `#F1F5F9` (Slate 100) | Card/row hover |
| **Border** | `#E2E8F0` (Slate 200) | Dividers, card borders |
| **Text Primary** | `#0F172A` (Slate 900) | Headings, body text |
| **Text Secondary** | `#64748B` (Slate 500) | Labels, timestamps |
| **Text Muted** | `#94A3B8` (Slate 400) | Placeholders, disabled |

#### Dark Mode

| Token | Hex | Usage |
|-------|-----|-------|
| **Primary** | `#3B82F6` (Blue 500) | Buttons, links |
| **Accent** | `#8B5CF6` (Violet 500) | Special highlights |
| **Success** | `#22C55E` (Green 500) | Done status |
| **Warning** | `#F59E0B` (Amber 500) | Medium priority |
| **Danger** | `#EF4444` (Red 500) | High priority, errors |
| **Background** | `#0F172A` (Slate 900) | Main background |
| **Surface** | `#1E293B` (Slate 800) | Cards, sidebars |
| **Surface Hover** | `#334155` (Slate 700) | Hover states |
| **Border** | `#334155` (Slate 700) | Dividers |
| **Text Primary** | `#F8FAFC` (Slate 50) | Headings, body |
| **Text Secondary** | `#94A3B8` (Slate 400) | Labels |
| **Text Muted** | `#64748B` (Slate 500) | Disabled |

### 9.2.2. Typography

| Element | Font | Weight | Size | Line Height |
|---------|------|--------|------|-------------|
| **H1 (Page Title)** | Be Vietnam Pro | 700 | 28px | 1.3 |
| **H2 (Section Title)** | Be Vietnam Pro | 600 | 22px | 1.35 |
| **H3 (Card Title)** | Be Vietnam Pro | 600 | 18px | 1.4 |
| **Body** | Inter | 400 | 15px | 1.6 |
| **Body Small** | Inter | 400 | 13px | 1.5 |
| **Label** | Inter | 500 | 13px | 1.4 |
| **Caption** | Inter | 400 | 12px | 1.4 |
| **Button** | Inter | 500 | 14px | 1 |

**Font Stack:**
```
font-family: 'Be Vietnam Pro', 'Inter', system-ui, -apple-system, sans-serif;
```

### 9.2.3. Spacing System

Base unit: **4px**

| Token | Value | Usage |
|-------|-------|-------|
| `space-1` | 4px | Tight gaps |
| `space-2` | 8px | Component internal padding |
| `space-3` | 12px | Input padding |
| `space-4` | 16px | Standard padding |
| `space-5` | 20px | Card padding |
| `space-6` | 24px | Section spacing |
| `space-8` | 32px | Large gaps |
| `space-10` | 40px | Section separators |
| `space-12` | 48px | Page-level spacing |

### 9.2.4. Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| `radius-sm` | 6px | Badges, small elements |
| `radius-md` | 8px | Inputs, buttons |
| `radius-lg` | 12px | Cards |
| `radius-xl` | 16px | Modals |
| `radius-full` | 9999px | Avatars, pills |

### 9.2.5. Shadows

| Token | Value | Usage |
|-------|-------|-------|
| `shadow-sm` | `0 1px 2px rgba(0,0,0,0.05)` | Subtle elevation |
| `shadow-md` | `0 4px 6px rgba(0,0,0,0.07)` | Cards, dropdowns |
| `shadow-lg` | `0 10px 15px rgba(0,0,0,0.1)` | Modals, popovers |

---

## 9.3. Component Specifications

### 9.3.1. Button

| Variant | Style | Usage |
|---------|-------|-------|
| **Primary** | Blue 600 bg, white text | Main actions (Create, Save, Submit) |
| **Accent** | Violet 600 bg, white text | AI features, special CTAs |
| **Secondary** | White bg, slate border, slate text | Secondary actions |
| **Ghost** | Transparent, slate text | Tertiary actions, in-toolbar |
| **Danger** | Red 600 bg, white text | Delete, destructive actions |

| Size | Padding | Font Size |
|------|---------|-----------|
| **sm** | 8px 12px | 13px |
| **md** | 10px 16px | 14px |
| **lg** | 12px 20px | 15px |

### 9.3.2. Card

```css
/* Base card */
.ez-card {
  background: white;
  border: 1px solid #E2E8F0;
  border-radius: 12px;
  padding: 16px-24px;
  transition: box-shadow 0.2s ease;
}

/* Hover state */
.ez-card:hover {
  box-shadow: 0 4px 6px rgba(0,0,0,0.07);
}
```

### 9.3.3. Avatar

| Size | Diameter | Font Size (initials) |
|------|---------|---------------------|
| **sm** | 28px | 10px |
| **md** | 36px | 13px |
| **lg** | 44px | 16px |
| **xl** | 64px | 24px |

- **Image**: Rounded full (`border-radius: 9999px`)
- **Fallback**: Colored background from `ui-avatars.com`, white initials
- **Online indicator**: Green dot (8px) positioned bottom-right

### 9.3.4. Badge / Status Chip

| Status | Background | Text | Border |
|--------|-----------|------|--------|
| **Backlog** | Slate 100 | Slate 600 | none |
| **In Progress** | Blue 100 | Blue 700 | none |
| **Review** | Amber 100 | Amber 700 | none |
| **Done** | Green 100 | Green 700 | none |
| **On Hold** | Slate 100 | Slate 500 | none |
| **Cancelled** | Red 50 | Red 600 | none |
| **High Priority** | Red 100 | Red 700 | none |
| **Medium Priority** | Amber 100 | Amber 700 | none |
| **Low Priority** | Slate 100 | Slate 500 | none |

### 9.3.5. Input Fields

| State | Border | Background |
|-------|--------|-----------|
| **Default** | Slate 200 | White |
| **Focus** | Blue 500 (ring) | White |
| **Error** | Red 500 | Red 50 |
| **Disabled** | Slate 200 | Slate 50 |

### 9.3.6. Modal

| Property | Value |
|----------|-------|
| **Width** | sm: 400px, md: 560px, lg: 720px |
| **Border radius** | 16px |
| **Backdrop** | Black at 50% opacity |
| **Animation** | Fade in + scale from 95% to 100%, 200ms |
| **Padding** | 24px |
| **Header border** | Bottom border slate 200 |
| **Footer** | Right-aligned buttons, gap 12px |

### 9.3.7. Toast Notification

| Type | Color Accent | Icon |
|------|-------------|------|
| **Success** | Green 600 left border | CheckCircle |
| **Error** | Red 600 left border | XCircle |
| **Warning** | Amber 600 left border | AlertTriangle |
| **Info** | Blue 600 left border | Info |

- Position: Top-right
- Auto-dismiss: 5 seconds
- Max visible: 3 (queue overflow)

---

## 9.4. Page Layouts

### 9.4.1. App Shell Layout

```
┌──────────────────────────────────────────────────────────┐
│ Topbar (h: 56px)                                         │
│ [Logo] [Search] ............... [Lang] [Theme] [🔔] [👤]│
├────────────┬─────────────────────────────────────────────┤
│            │                                             │
│  Sidebar   │  Main Content Area                          │
│  (w: 240px │                                             │
│   or 64px  │  ┌───────────────────────────────────────┐  │
│  collapsed)│  │ Page Header                           │  │
│            │  │ [Title] ............. [Actions]       │  │
│  [Dashboard]│  ├───────────────────────────────────────┤  │
│  [Settings]│  │                                       │  │
│  [Profile] │  │ Content                                │  │
│            │  │                                       │  │
│  Projects: │  │                                       │  │
│  ├─ proj-1 │  │                                       │  │
│  ├─ proj-2 │  │                                       │  │
│  └─ proj-3 │  └───────────────────────────────────────┘  │
│            │                                             │
└────────────┴─────────────────────────────────────────────┘
```

### 9.4.2. Project Layout

```
┌──────────────────────────────────────────────────────────┐
│ Project Topbar (h: 52px)                                 │
│ [← Back] [Project Name] ................ [Members avatars]│
├────────────┬─────────────────────────────────────────────┤
│            │                                             │
│  Sidebar   │  Project Sub-nav                           │
│            │  [Overview] [Tasks] [Docs] [Members]       │
│  (same as  │  [Meetings] [Chat] [Performance]           │
│   above)   ├─────────────────────────────────────────────┤
│            │                                             │
│            │  Page Content                              │
│            │  (varies by active tab)                    │
│            │                                             │
└────────────┴─────────────────────────────────────────────┘
```

### 9.4.3. Chat Page Layout

```
┌──────────────────────────────────────────────────────────┐
│ Topbar                                                    │
├────────────┬──────────────────┬───────────────────────────┤
│            │                  │                           │
│ Chat       │  Message Area    │  (Optional)               │
│ Sidebar    │                  │  Member List /             │
│ (w: 260px) │  ┌────────────┐  │  AI Assistant             │
│            │  │ Messages   │  │  Panel                    │
│ [Channels] │  │            │  │                           │
│  ├ General │  │            │  │                           │
│  ├ Frontend│  │            │  │                           │
│  └ Backend │  │            │  │                           │
│            │  │            │  │                           │
│ [DMs]      │  │            │  │                           │
│  ├ Bob     │  ├────────────┤  │                           │
│  └ Charlie │  │ [Input]    │  │                           │
│            │  └────────────┘  │                           │
└────────────┴──────────────────┴───────────────────────────┘
```

### 9.4.4. Task Kanban Board Layout

```
┌──────────────────────────────────────────────────────────────────┐
│ Page Header                                                        │
│ [Tasks] .................. [Filter] [Search] [+ Add Task]        │
├──────────────────────────────────────────────────────────────────┤
│ Kanban Board (horizontal scroll)                                   │
│                                                                   │
│ [Backlog (5)]  [In Progress (3)]  [Review (2)]  [Done (15)] [Hold]│
│ ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ ┌────────┐ │
│ │Task Card │  │Task Card │  │Task Card │  │Task Card │ │Task Card│
│ │          │  │          │  │          │  │          │ │        │
│ │ Priority │  │ Priority │  │ Priority │  │ Priority │ │Priority│
│ │ Assignee │  │ Assignee │  │ Assignee │  │ Assignee │ │Assignee│
│ │ Deadline │  │ Deadline │  │ Deadline │  │ Deadline │ │Deadline│
│ └──────────┘  └──────────┘  └──────────┘  └──────────┘ └────────┘ │
│                                                                   │
│ [Drag & Drop between columns]                                     │
└──────────────────────────────────────────────────────────────────┘
```

---

## 9.5. Responsive Breakpoints

| Breakpoint | Width | Layout Behavior |
|------------|-------|----------------|
| **sm** | 640px+ | Single column, smaller sidebar |
| **md** | 768px+ | Standard layout |
| **lg** | 1024px+ | Full sidebar expanded |
| **xl** | 1280px+ | Wider content area |
| **2xl** | 1536px+ | Max content width 1400px |

### Responsive Strategy

| Component | < 768px | 768px - 1024px | > 1024px |
|-----------|---------|----------------|----------|
| **Sidebar** | Hidden (hamburger menu) | Collapsed (icons only) | Expanded |
| **Task Board** | Single column scroll | 2 columns | 5 columns |
| **Chat Sidebar** | Full screen drawer | Narrow (200px) | Full (260px) |
| **Document Viewer** | Stacked (list + viewer) | Split view | 3-panel |

---

## 9.6. Icon Library

Using **Lucide React** exclusively for all icons.

### Key Icons Used

| Context | Icon | Size |
|---------|------|------|
| **Navigation** | LayoutDashboard, FolderKanban, FileText, Users, Calendar, MessageSquare, BarChart3 |
| **Actions** | Plus, Edit2, Trash2, Search, Filter, Download, Upload, Send |
| **Status** | CheckCircle, Clock, AlertCircle, XCircle, Pause |
| **Priority** | ArrowUp (High), Minus (Medium), ArrowDown (Low) |
| **General** | Bell, Settings, Moon, Sun, Globe, ChevronDown, ChevronRight, X |
| **AI** | Bot, Sparkles |
| **Roles** | Crown (leader), Eye (supervisor), User (member) |

---

## 9.7. Animation Guidelines

### 9.7.1. Animation Principles

| Principle | Implementation |
|-----------|---------------|
| **Purposeful** | Animations guide attention, not distract |
| **Fast** | Duration: 150ms–300ms for micro-interactions |
| **Smooth** | Easing: `ease-out` for entries, `ease-in` for exits |
| **Respectful** | Honor `prefers-reduced-motion` |

### 9.7.2. Animation Specs

| Animation | Duration | Easing | Trigger |
|-----------|----------|--------|---------|
| **Page transition** | 200ms | ease-out | Route change |
| **Modal open** | 200ms | ease-out (scale 0.95→1) | Click |
| **Modal close** | 150ms | ease-in (scale 1→0.95) | Click backdrop/Escape |
| **Sidebar collapse** | 200ms | ease-in-out | Toggle click |
| **Button hover** | 150ms | ease-out | Mouse enter |
| **Card hover** | 150ms | ease-out | Mouse enter |
| **Toast appear** | 300ms | ease-out (slide + fade) | Auto/Action |
| **Toast dismiss** | 200ms | ease-in | Auto/Click |
| **Drag start** | 100ms | ease-out | Drag |
| **Drop** | 200ms | ease-out (snap) | Release |
| **Drawer slide** | 250ms | ease-in-out | Open/close |
| **Skeleton pulse** | 1.5s | ease-in-out (loop) | Loading state |

### 9.7.3. Reduced Motion

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## 9.8. Loading States

### 9.8.1. Skeleton Components

| Component | Skeleton Pattern |
|-----------|------------------|
| **Card** | Rectangle with title + 2 lines |
| **List** | Repeated skeleton rows (4-6 items) |
| **Avatar** | Circle skeleton |
| **Table** | Header row + 5 body rows |
| **Kanban Column** | 3 skeleton cards per column |

### 9.8.2. Progress Indicators

| Context | Indicator |
|---------|----------|
| **Page loading** | Full-page skeleton |
| **Component loading** | Component-level skeleton |
| **Action in progress** | Spinner (Button with spinner + disabled) |
| **Upload progress** | Progress bar with % |
| **Task completion** | Checkmark animation |

---

## 9.9. Empty States

Every feature with a list has an empty state component:

| Page | Empty State Message | Action |
|------|---------------------|--------|
| **Projects** | "Chưa có dự án nào" | "Tạo dự án đầu tiên" button |
| **Tasks** | "Chưa có công việc" | "Thêm công việc" button |
| **Documents** | "Thư mục trống" | "Tải file lên" button |
| **Meetings** | "Chưa có cuộc họp" | "Lên lịch họp" button |
| **Chat** | "Chưa có tin nhắn" | Prompt to start conversation |
| **Notifications** | "Không có thông báo" | Check back later message |

---

## 9.10. Microcopy Guidelines

### Tone of Voice

- **Friendly but professional**: Không quá formal, không quá casual
- **Vietnamese-first**: Giao diện mặc định là tiếng Việt
- **Action-oriented**: Button labels dùng động từ: "Tạo dự án", "Thêm công việc", "Lưu thay đổi"
- **Error messages**: Cụ thể, hữu ích, gợi ý hành động tiếp theo

### Example Microcopy

| Context | English | Vietnamese |
|---------|---------|------------|
| **Empty tasks** | "No tasks yet" | "Chưa có công việc" |
| **Add button** | "Add Task" | "Thêm công việc" |
| **Save button** | "Save Changes" | "Lưu thay đổi" |
| **Error: empty field** | "Title is required" | "Tiêu đề không được để trống" |
| **Success: created** | "Project created successfully" | "Đã tạo dự án" |
| **Loading** | "Loading..." | "Đang tải..." |
| **Welcome** | "Welcome back, {name}" | "Chào mừng trở lại, {name}" |

---

## 9.11. Design Tool

| Asset | Tool | Notes |
|-------|------|-------|
| **Wireframes** | Figma | Low-fi wireframes for layout |
| **Mockups** | Figma | High-fi designs with design system |
| **Prototype** | Figma | Clickable prototype for user testing |
| **Design System** | Figma + code | Component library in code + Figma |

### Figma Component Structure

```
EZProject Design System
├── Foundations
│   ├── Colors
│   ├── Typography
│   ├── Spacing
│   └── Icons
├── Components
│   ├── Buttons
│   ├── Cards
│   ├── Inputs
│   ├── Badges
│   ├── Avatars
│   ├── Modals
│   ├── Toasts
│   └── Navigation
└── Pages
    ├── Landing
    ├── Auth (Login/Register)
    ├── Dashboard
    ├── Project
    ├── Tasks
    ├── Documents
    ├── Chat
    └── Performance
```
