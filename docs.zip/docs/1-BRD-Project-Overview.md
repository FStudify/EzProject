# 1. BRD — Project Overview
## Business Requirement Document

> **Project Name:** EZProject
> **Version:** 1.0
> **Date:** May 2026
> **Status:** Draft

---

## 1.1. Project Overview

**Project Name:** EZProject — Nền tảng Quản lý Dự án cho Sinh viên

**Project Type:** Web Application (Single Page Application — SPA)

**Short Description:**
EZProject là nền tảng quản lý dự án nhóm dành riêng cho sinh viên Việt Nam, tích hợp quản lý công việc (Kanban/Timeline), thảo luận nhóm (Chat), lịch họp, lưu trữ tài liệu, và theo dõi hiệu suất trong một không gian làm việc duy nhất — giúp loại bỏ sự phân mảnh thông tin và giảm thiểu "đùn đẩy" trách nhiệm.

---

## 1.2. Team Setup & Roles

| Role | Name | Responsibilities |
|------|------|-----------------|
| **CEO** | Quốc Hiệu | Ý tưởng chính, chiến lược kinh doanh, lộ trình phát triển sản phẩm |
| **CMO** | Nguyễn Thanh | Quảng bá, tiếp cận người dùng, social media |
| **CTO** | Bảo Khánh | Kiến trúc kỹ thuật, lựa chọn công nghệ |
| **UI/UX Designer** | Hồ Hưng | Thiết kế giao diện tối giản, trải nghiệm người dùng |
| **Product Manager** | Huyền Trân | Cầu nối yêu cầu kinh doanh – kỹ thuật, quản lý đầu việc |
| **QA** | Ngọc Khánh | Kiểm soát chất lượng, đảm bảo sản phẩm không lỗi |

---

## 1.3. Market Pain Points

### 1.3.1. Sự hỗn loạn thông tin (Communication Chaos)
Sinh viên bị kẹt trong một "ngăn xếp công nghệ" rời rạc, chắp vá giữa Zalo (thảo luận) và Google Drive/Docs (làm bài). Dẫn đến trôi tin nhắn, thất thoát dữ liệu, nộp nhầm phiên bản cũ.

### 1.3.2. Hội chứng "Trang giấy trắng" (Methodology Gap)
Sinh viên thiếu kỹ năng phương pháp luận để bắt đầu dự án phức tạp. Mất quá nhiều thời gian loay hoay nghĩ cách chia nhỏ công việc và bước đầu tiên cần làm gì.

### 1.3.3. Rào cản từ công cụ quá phức tạp (Tool Complexity)
Các công cụ hiện có (Notion, Jira) có độ khó cao (learning curve), bắt sinh viên tốn hàng giờ để "học cách dùng app" thay vì tập trung làm bài tập.

---

## 1.4. Problem Statement

> Sinh viên tại Việt Nam đang thiếu một môi trường quản lý dự án chuyên biệt, nơi họ có thể dễ dàng bắt đầu mà không cần tốn quá nhiều thời gian để học cách dùng app, đồng thời phải đảm bảo tính minh bạch, xóa bỏ sự mơ hồ trong việc phân công nhiệm vụ để loại bỏ tình trạng đùn đẩy trách nhiệm và quản lý tiến độ hiệu quả.

---

## 1.5. Solution — Nền tảng "EZProject"

### 1.5.1. Không gian làm việc tập trung (Centralized Hub)
Tích hợp thảo luận + quản lý tài liệu tại một nơi duy nhất, loại bỏ sự phân mảnh thông tin.

### 1.5.2. Hệ thống Quy trình mẫu (Template-first)
Thư viện quy trình có sẵn cho từng đặc thù môn học (Marketing, IT, Triết học...). Sinh viên chọn mẫu và bắt tay vào việc ngay.

### 1.5.3. Theo dõi tiến độ trực quan (Visual Tracking)
Giao diện hiển thị rõ "Ai đang làm gì?", "Deadline khi nào?", "Nhiệm vụ nào đang gặp vướng mắc?". Sự minh bạch giúp quản lý hiệu quả.

---

## 1.6. Target Users

| User Segment | Description |
|--------------|-------------|
| **Sinh viên đại học/cao đẳng** | Người dùng chính, cần quản lý bài tập nhóm, đồ án |
| **Nhóm trưởng (Team Leader)** | Cần tổ chức, phân công, theo dõi tiến độ nhóm |
| **Giảng viên/Giám sát** | Theo dõi tiến độ dự án của nhóm (future scope) |

---

## 1.7. Project Scope

### In Scope (v1.0)
- Authentication (Login / Register)
- Dashboard tổng quan
- Quản lý Dự án (CRUD Projects)
- Quản lý Công việc (Kanban Board + Timeline View)
- Quản lý Tài liệu (Upload, Preview DOCX/PDF/IMG/ZIP, Folder organization)
- Quản lý Cuộc họp (Schedule, RSVP, Online/Offline)
- Trò chuyện nhóm (Chat channels + Direct Messages)
- Theo dõi Hiệu suất (Contribution graph, Member evaluation)
- Hồ sơ & Cài đặt (Theme, Language)
- AI Assistant Chat (trả lời câu hỏi về project management)
- Landing Page công khai

### Out of Scope (v1.0)
- Backend / Database thực sự (hiện tại là mock data)
- Real-time WebSocket chat
- Push Notifications
- Email notifications
- Mobile app
- Export báo cáo (PDF/Excel)
- Quản lý điểm số của giảng viên

---

## 1.8. Feature Overview

| Module | Key Features |
|--------|-------------|
| **Auth** | Login, Register, Protected Route, Guest Route, Demo Login |
| **Dashboard** | Welcome greeting, project cards, activity feed, upcoming meetings |
| **Projects** | List, create, overview, member management, progress tracking |
| **Tasks** | Kanban board (5 columns), Timeline view, drag-and-drop, task modal, comments, filters |
| **Documents** | Folder tree, file upload, preview (DOCX via docx-preview, PDF via PDF.js, images), rename, delete |
| **Meetings** | Schedule, RSVP (Attend/Decline), online link / offline location, status tracking |
| **Chat** | Channels (General, team channels), Direct Messages, message bubbles, AI assistant dialog |
| **Performance** | Contribution graph (GitHub-style), task stats per member, member evaluation/rating |
| **Profile** | View/edit profile info, avatar |
| **Settings** | Theme toggle (Light/Dark), Language switch (VI/EN), account settings |
| **Landing Page** | Hero, features showcase, CTA buttons |

---

## 1.9. Business Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                     EZProject User Flow                         │
└─────────────────────────────────────────────────────────────────┘

[Landing Page] ─── "Get Started" ──→ [Login / Register]
                                            │
                                       [Auth Success]
                                            │
                                     [Dashboard (App)]
                                            │
              ┌──────────────┬──────────────┼──────────────┐
              │              │              │              │
         [Projects]    [Tasks Board]  [Documents]   [Chat Room]
              │              │              │              │
              │         [Kanban/Timeline]   │         [Channels/DM]
              │              │              │              │
         [Project        [Task Modal]  [File Preview]  [AI Assistant]
          Overview]    [Add Task]    [Upload File]
              │
         [Members]
         [Meetings]
         [Performance]
```

---

## 1.10. KPI / Success Criteria

| Metric | Target | Measurement |
|--------|--------|-------------|
| Task completion rate | > 80% tasks done before deadline | Tasks with status=DONE vs total |
| Onboarding time | Người dùng mới login và bắt đầu task đầu tiên trong < 5 phút | User testing |
| UI responsiveness | Tất cả tương tác < 200ms | Chrome DevTools |
| Zero dead pages | Mọi button/link có hành động hợp lệ | QA testing |
| Cross-browser compatibility | Hoạt động tốt trên Chrome, Firefox, Edge | Manual testing |

---

## 1.11. Tech Stack Summary

| Layer | Technology |
|-------|-----------|
| **Frontend Framework** | React 19 + TypeScript |
| **Build Tool** | Vite 7 |
| **Styling** | Tailwind CSS v4 |
| **Routing** | React Router v7 |
| **Icons** | Lucide React |
| **Document Viewer** | pdfjs-dist (PDF), docx-preview (DOCX) |
| **i18n** | Custom (VI/EN) |
| **State** | React Context + localStorage |

> **Note:** Dự án hiện tại là **Frontend-only** với mock data. Backend/Database sẽ được phát triển trong phase tiếp theo.

---

## 1.12. Project Structure

```
Frontend/
├── src/
│   ├── components/          # Reusable UI + Layout components
│   │   ├── ui/              # Base components (Button, Card, Modal, Toast...)
│   │   └── layout/          # AppLayout, Sidebar, Topbar, ProjectLayout
│   ├── features/            # Feature modules
│   │   ├── auth/            # Login, Register, AuthContext
│   │   ├── dashboard/       # DashboardPage
│   │   ├── projects/         # ProjectList, ProjectCard, ProjectOverview
│   │   ├── tasks/           # TaskBoard, TaskColumn, TaskCard, TaskModal
│   │   ├── documents/       # DocumentPage, DocxViewer, PdfViewer
│   │   ├── members/         # MemberList
│   │   ├── meetings/        # MeetingList
│   │   ├── chat/            # ChatPage, ChatPanel, AIChatDialog
│   │   ├── performance/     # PerformancePage, ContributionGraph
│   │   ├── profile/         # ProfilePage, SettingsPage
│   │   └── landing/         # LandingPage
│   ├── contexts/            # ThemeContext, LanguageContext
│   ├── i18n/                # Vietnamese & English dictionaries
│   ├── mocks/               # Mock data (projects, tasks, members, documents...)
│   ├── services/            # Mock services (taskService, projectService)
│   ├── types/               # TypeScript interfaces & types
│   ├── lib/                 # Utilities (greeting)
│   ├── App.tsx              # Root component with router
│   └── main.tsx             # Entry point
├── public/                  # Static assets
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
└── eslint.config.js
```
