# 4. Database Design
## Schema Specification for EZProject Backend

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026
> **Note:** Dự án hiện tại là Frontend-only với mock data. Tài liệu này mô tả thiết kế database cho backend phase tiếp theo.

---

## 4.1. ERD Overview

```
┌──────────────┐       ┌──────────────────┐       ┌──────────────────┐
│    users     │       │    projects      │       │   project_users  │
│──────────────│       │──────────────────│       │──────────────────│
│ PK id        │◀──┐   │ PK id            │◀──┐   │ PK user_id       │
│    email     │   │   │    name          │   │   │ PK project_id   │
│    username  │   │   │    description   │   │   │    role          │
│    password  │   │   │    subject        │   │   │    is_owner      │
│    full_name │   │   │    status         │   │   └──────────────────┘
│    avatar    │   │   │    progress       │   │           │
│    phone     │   │   │    deadline       │   │           │
│    department│   │   │    created_at      │   │           │
│    position  │   │   │    owner_id ───────┼───┘           │
│    bio       │   │   └──────────────────┘           │
│    created_at│   │           │                       │
└──────────────┘   │           │                       │
      │            │           │                       │
      │            │     ┌─────┴─────┬──────────┐     │
      │            │     │           │          │     │
      │            │     ▼           ▼          ▼     │
      │            │ ┌────────┐ ┌─────────┐ ┌────────┐│
      │            │ │ tasks  │ │documents│ │meetings││
      │            │ │────────│ │─────────│ │────────││
      └────────────┼▶│PK id   │ │PK id    │ │PK id   ││
                   │ │FK proj │ │FK proj  │ │FK proj ││
                   │ │FK asgn │ │FK uploader│FK org ││
                   │ │FK creator│         │ │        ││
                   │ │        │ │         │ │        ││
                   │ └────────┘ └─────────┘ └────────┘│
                   │     │           │          │       │
                   │     ▼           ▼          ▼       │
                   │ ┌────────┐ ┌─────────┐ ┌────────┐│
                   │ │comments│ │folders  │ │attendees│
                   │ │────────│ │─────────│ │────────││
                   │ │PK id   │ │PK id    │ │FK meet ││
                   │ │FK task │ │FK proj  │ │FK user ││
                   │ │FK user │ │         │ │response││
                   │ └────────┘ └─────────┘ └────────┘│
                   │     │
                   │     ▼
                   │ ┌─────────────────────────────┐
                   │ │      chat_rooms              │
                   │ │─────────────────────────────│
                   │ │ PK id                        │
                   │ │ FK project_id                │
                   │ │    name                      │
                   │ │    type (general/channel/dm) │
                   │ │    created_at                │
                   │ └─────────────┬───────────────┘
                   │               │
                   │               ▼
                   │ ┌─────────────────────────────┐
                   │ │      chat_messages           │
                   │ │─────────────────────────────│
                   │ │ PK id                        │
                   │ │ FK room_id                   │
                   │ │ FK sender_id (nullable for AI)│
                   │ │    content                   │
                   │ │    channel (group/task/doc/ai│
                   │ │    timestamp                 │
                   │ └─────────────────────────────┘
```

---

## 4.2. Table Schemas

### 4.2.1. `users`

Lưu trữ thông tin người dùng.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `email` | VARCHAR(255) | UNIQUE, NOT NULL | Email address |
| `username` | VARCHAR(100) | UNIQUE, NOT NULL | Login username |
| `password_hash` | VARCHAR(255) | NOT NULL | Bcrypt hashed password |
| `full_name` | VARCHAR(255) | NOT NULL | Họ và tên |
| `avatar` | VARCHAR(500) | NULL | URL ảnh đại diện |
| `phone` | VARCHAR(20) | NULL | Số điện thoại |
| `department` | VARCHAR(100) | NULL | Khoa/phòng ban |
| `position` | VARCHAR(100) | NULL | Chức vụ |
| `bio` | TEXT | NULL | Giới thiệu bản thân |
| `language` | ENUM('vi','en') | DEFAULT 'vi' | Ngôn ngữ ưu thích |
| `theme` | ENUM('light','dark') | DEFAULT 'light' | Giao diện ưu thích |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |
| `updated_at` | TIMESTAMP | DEFAULT NOW() | Ngày cập nhật |

### 4.2.2. `projects`

Lưu trữ thông tin dự án/nhóm.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `name` | VARCHAR(255) | NOT NULL | Tên dự án |
| `description` | TEXT | NULL | Mô tả dự án |
| `subject` | VARCHAR(255) | NULL | Tên môn học |
| `status` | ENUM('active','completed','archived') | DEFAULT 'active' | Trạng thái |
| `progress` | INTEGER | DEFAULT 0 | % hoàn thành (0-100) |
| `owner_id` | UUID | FK → users.id, NOT NULL | Người tạo project |
| `deadline` | TIMESTAMP | NULL | Hạn chót |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |
| `updated_at` | TIMESTAMP | DEFAULT NOW() | Ngày cập nhật |

### 4.2.3. `project_users`

Bảng trung gian quản lý quan hệ nhiều-nhiều giữa projects và users.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `user_id` | UUID | PK, FK → users.id | Thành viên |
| `project_id` | UUID | PK, FK → projects.id | Dự án |
| `role` | ENUM('leader','supervisor','member') | DEFAULT 'member' | Vai trò trong project |
| `is_owner` | BOOLEAN | DEFAULT FALSE | Có phải chủ dự án không |
| `joined_at` | TIMESTAMP | DEFAULT NOW() | Ngày tham gia |

### 4.2.4. `tasks`

Lưu trữ công việc trong dự án.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án chứa task |
| `title` | VARCHAR(500) | NOT NULL | Tiêu đề công việc |
| `description` | TEXT | NULL | Mô tả chi tiết |
| `status` | ENUM('BACKLOG','IN_PROGRESS','REVIEW','DONE','ON_HOLD','CANCELLED') | DEFAULT 'BACKLOG' | Trạng thái |
| `priority` | ENUM('LOW','MEDIUM','HIGH') | DEFAULT 'MEDIUM' | Độ ưu tiên |
| `assignee_id` | UUID | FK → users.id, NULL | Người phụ trách |
| `creator_id` | UUID | FK → users.id, NOT NULL | Người tạo |
| `deadline` | TIMESTAMP | NULL | Hạn chót |
| `request_type` | ENUM('review','pause') | NULL | Loại request |
| `request_note` | TEXT | NULL | Ghi chú kèm request |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |
| `updated_at` | TIMESTAMP | DEFAULT NOW() | Ngày cập nhật |

### 4.2.5. `task_comments`

Lưu trữ bình luận trên task.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `task_id` | UUID | FK → tasks.id, NOT NULL | Task liên quan |
| `author_id` | UUID | FK → users.id, NOT NULL | Người viết |
| `content` | TEXT | NOT NULL | Nội dung bình luận |
| `mentions` | JSONB | DEFAULT '[]' | Array of mentioned user IDs |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.6. `documents`

Lưu trữ tài liệu trong dự án.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án chứa tài liệu |
| `folder_id` | UUID | FK → folders.id, NULL | Thư mục chứa (NULL = root) |
| `name` | VARCHAR(500) | NOT NULL | Tên file |
| `file_type` | ENUM('DOC','PDF','PPT','ZIP','IMG','OTHER') | NOT NULL | Loại file |
| `size` | VARCHAR(20) | NOT NULL | Kích thước file (VD: "1.2 MB") |
| `file_url` | VARCHAR(1000) | NULL | URL để download/preview |
| `uploaded_by` | UUID | FK → users.id, NOT NULL | Người upload |
| `upload_date` | TIMESTAMP | DEFAULT NOW() | Ngày upload |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.7. `folders`

Lưu trữ cấu trúc thư mục.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án |
| `parent_id` | UUID | FK → folders.id, NULL | Thư mục cha (NULL = root) |
| `name` | VARCHAR(255) | NOT NULL | Tên thư mục |
| `created_by` | UUID | FK → users.id, NOT NULL | Người tạo |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.8. `document_comments`

Lưu trữ bình luận trên tài liệu.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `document_id` | UUID | FK → documents.id, NOT NULL | Tài liệu liên quan |
| `author_id` | UUID | FK → users.id, NOT NULL | Người viết |
| `content` | TEXT | NOT NULL | Nội dung bình luận |
| `mentions` | JSONB | DEFAULT '[]' | Array of mentioned user IDs |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.9. `meetings`

Lưu trữ thông tin cuộc họp.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án |
| `title` | VARCHAR(500) | NOT NULL | Tiêu đề cuộc họp |
| `description` | TEXT | NULL | Mô tả |
| `type` | ENUM('online','offline') | NOT NULL | Loại hình |
| `start_time` | TIMESTAMP | NOT NULL | Thời gian bắt đầu |
| `end_time` | TIMESTAMP | NOT NULL | Thời gian kết thúc |
| `location` | VARCHAR(500) | NULL | Địa điểm (offline) |
| `meeting_link` | VARCHAR(1000) | NULL | Link họp online |
| `status` | ENUM('scheduled','in_progress','completed','cancelled') | DEFAULT 'scheduled' | Trạng thái |
| `organizer_id` | UUID | FK → users.id, NOT NULL | Người tổ chức |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |
| `updated_at` | TIMESTAMP | DEFAULT NOW() | Ngày cập nhật |

### 4.2.10. `meeting_attendees`

Lưu trữ danh sách người tham gia và phản hồi RSVP.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `meeting_id` | UUID | PK, FK → meetings.id | Cuộc họp |
| `user_id` | UUID | PK, FK → users.id | Người được mời |
| `will_attend` | BOOLEAN | NULL | Có tham dự không (NULL = pending) |
| `decline_reason` | TEXT | NULL | Lý do từ chối |
| `responded_at` | TIMESTAMP | NULL | Thời gian phản hồi |

### 4.2.11. `chat_rooms`

Lưu trữ phòng chat.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án |
| `name` | VARCHAR(255) | NOT NULL | Tên phòng |
| `type` | ENUM('general','channel','direct') | NOT NULL | Loại phòng |
| `created_by` | UUID | FK → users.id, NOT NULL | Người tạo |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.12. `chat_room_members`

Bảng trung gian cho thành viên trong phòng chat.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `room_id` | UUID | PK, FK → chat_rooms.id | Phòng chat |
| `user_id` | UUID | PK, FK → users.id | Thành viên |
| `joined_at` | TIMESTAMP | DEFAULT NOW() | Ngày tham gia |

### 4.2.13. `chat_messages`

Lưu trữ tin nhắn chat.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `room_id` | UUID | FK → chat_rooms.id, NOT NULL | Phòng chat |
| `sender_id` | UUID | FK → users.id, NULL | Người gửi (NULL cho AI) |
| `content` | TEXT | NOT NULL | Nội dung tin nhắn |
| `channel` | ENUM('group','task','document','ai') | DEFAULT 'group' | Loại kênh |
| `target_id` | UUID | NULL | ID của task/document liên quan (nếu channel != 'group') |
| `timestamp` | TIMESTAMP | DEFAULT NOW() | Thời gian gửi |

### 4.2.14. `activities`

Lưu trữ feed hoạt động.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án |
| `user_id` | UUID | FK → users.id, NOT NULL | Người thực hiện |
| `action` | VARCHAR(100) | NOT NULL | Hành động (VD: "uploaded", "completed") |
| `target` | VARCHAR(500) | NOT NULL | Đối tượng (VD: "Báo cáo.docx") |
| `target_type` | VARCHAR(50) | NULL | Loại đối tượng (task/document/meeting) |
| `target_id` | UUID | NULL | ID của đối tượng |
| `timestamp` | TIMESTAMP | DEFAULT NOW() | Thời gian |

### 4.2.15. `notifications`

Lưu trữ thông báo.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `user_id` | UUID | FK → users.id, NOT NULL | Người nhận |
| `type` | ENUM('task','meeting','chat','document') | NOT NULL | Loại thông báo |
| `title` | VARCHAR(500) | NOT NULL | Tiêu đề |
| `body` | TEXT | NOT NULL | Nội dung |
| `link` | VARCHAR(1000) | NULL | Đường dẫn khi click |
| `read` | BOOLEAN | DEFAULT FALSE | Đã đọc chưa |
| `created_at` | TIMESTAMP | DEFAULT NOW() | Ngày tạo |

### 4.2.16. `member_evaluations`

Lưu trữ đánh giá thành viên.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | UUID | PK, NOT NULL | Unique identifier |
| `project_id` | UUID | FK → projects.id, NOT NULL | Dự án |
| `member_id` | UUID | FK → users.id, NOT NULL | Thành viên được đánh giá |
| `evaluator_id` | UUID | FK → users.id, NOT NULL | Người đánh giá |
| `rating` | INTEGER | CHECK (1-5) | Điểm đánh giá |
| `feedback` | TEXT | NULL | Nhận xét |
| `evaluated_at` | TIMESTAMP | DEFAULT NOW() | Thời gian đánh giá |

---

## 4.3. Table Relationships

| Parent Table | Child Table | Relationship Type | Description |
|-------------|------------|------------------|-------------|
| `users` | `projects` | 1:N | Một user có thể tạo nhiều project |
| `projects` | `project_users` | 1:N | Một project có nhiều project_users |
| `users` | `project_users` | 1:N | Một user có thể tham gia nhiều project_users |
| `projects` | `tasks` | 1:N | Một project có nhiều tasks |
| `users` | `tasks` (assignee) | 1:N | Một user có thể được gán nhiều tasks |
| `users` | `tasks` (creator) | 1:N | Một user có thể tạo nhiều tasks |
| `tasks` | `task_comments` | 1:N | Một task có nhiều comments |
| `projects` | `documents` | 1:N | Một project có nhiều documents |
| `folders` | `documents` | 1:N | Một folder có nhiều documents |
| `projects` | `folders` | 1:N | Một project có nhiều folders |
| `projects` | `meetings` | 1:N | Một project có nhiều meetings |
| `meetings` | `meeting_attendees` | 1:N | Một meeting có nhiều attendees |
| `projects` | `chat_rooms` | 1:N | Một project có nhiều rooms |
| `chat_rooms` | `chat_room_members` | 1:N | Một room có nhiều members |
| `chat_rooms` | `chat_messages` | 1:N | Một room có nhiều messages |
| `projects` | `activities` | 1:N | Một project có nhiều activities |
| `users` | `notifications` | 1:N | Một user có nhiều notifications |

---

## 4.4. Indexes

| Table | Index Name | Columns | Type | Purpose |
|-------|-----------|---------|------|---------|
| `users` | `idx_users_email` | `email` | UNIQUE | Fast lookup by email |
| `users` | `idx_users_username` | `username` | UNIQUE | Fast lookup by username |
| `tasks` | `idx_tasks_project` | `project_id` | B-TREE | Fast get tasks by project |
| `tasks` | `idx_tasks_assignee` | `assignee_id` | B-TREE | Fast get tasks by assignee |
| `tasks` | `idx_tasks_status` | `status` | B-TREE | Filter by status |
| `tasks` | `idx_tasks_deadline` | `deadline` | B-TREE | Filter by deadline |
| `documents` | `idx_docs_project` | `project_id` | B-TREE | Fast get docs by project |
| `documents` | `idx_docs_folder` | `folder_id` | B-TREE | Fast get docs by folder |
| `meetings` | `idx_meetings_project` | `project_id` | B-TREE | Fast get meetings by project |
| `meetings` | `idx_meetings_start` | `start_time` | B-TREE | Filter upcoming meetings |
| `chat_messages` | `idx_messages_room` | `room_id` | B-TREE | Fast get messages by room |
| `chat_messages` | `idx_messages_timestamp` | `timestamp` | B-TREE | Order by time |
| `activities` | `idx_activities_project` | `project_id` | B-TREE | Fast get activity by project |
| `activities` | `idx_activities_timestamp` | `timestamp` | DESC | Order by recent |
| `notifications` | `idx_notif_user` | `user_id` | B-TREE | Fast get notifs by user |
| `notifications` | `idx_notif_read` | `user_id, read` | COMPOSITE | Filter unread notifs |

---

## 4.5. Constraints & Business Rules

### 4.5.1. Check Constraints

| Constraint | Rule |
|------------|------|
| `member_evaluations.rating` | CHECK (rating >= 1 AND rating <= 5) |
| `projects.progress` | CHECK (progress >= 0 AND progress <= 100) |
| `meetings.end_time` | CHECK (end_time > start_time) |
| `project_users.role` | CHECK (role IN ('leader','supervisor','member')) |
| `tasks.status` | CHECK (status IN ('BACKLOG','IN_PROGRESS','REVIEW','DONE','ON_HOLD','CANCELLED')) |

### 4.5.2. Business Rules

| Rule | Description |
|------|-------------|
| **BR-01** | Mỗi project PHẢI có đúng 1 owner (is_owner = true). Owner không thể bị xóa khỏi project. |
| **BR-02** | Chỉ owner mới có quyền xóa project. |
| **BR-03** | Chỉ leader/supervisor mới có quyền đánh giá member. |
| **BR-04** | Không thể hạ vai trò của owner (is_owner = true). |
| **BR-05** | Mỗi project PHẢI có ít nhất 1 General room (type='general'). Không thể xóa General room. |
| **BR-06** | Direct message room (type='direct') chỉ có đúng 2 thành viên. |
| **BR-07** | Task với status='REVIEW' có thể có request_type='review' và request_note. |
| **BR-08** | Khi project chuyển sang 'completed', tất cả tasks phải có status='DONE' hoặc 'CANCELLED'. |

---

## 4.6. Recommended Tech Stack for Backend

| Component | Technology |
|-----------|-----------|
| **Database** | PostgreSQL 15+ |
| **ORM** | Prisma hoặc Drizzle ORM |
| **API** | Node.js + Express hoặc NestJS |
| **Auth** | JWT (access token) + Refresh token |
| **File Storage** | S3-compatible (AWS S3 / MinIO) |
| **Real-time** | Socket.io cho chat |
| **Cache** | Redis cho sessions và caching |

---

## 4.7. Mock Data Mapping (Frontend → Database)

Dữ liệu mock hiện tại trong `src/mocks/` tương ứng với các bảng trên:

| Mock File | Database Table(s) |
|-----------|-------------------|
| `members.ts` | `users` |
| `projects.ts` | `projects`, `project_users` |
| `tasks.ts` | `tasks`, `task_comments` |
| `documents.ts` | `documents`, `folders` |
| `meetings.ts` | `meetings`, `meeting_attendees` |
| `chatRooms.ts` | `chat_rooms`, `chat_room_members` |
| `chatMessages.ts` | `chat_messages` |
| `activities.ts` | `activities` |
| `notifications.ts` | `notifications` |
| `performance.ts` | `member_evaluations` (score) + aggregated from tasks/docs |
