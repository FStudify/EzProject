# 7. Non-Functional Requirements (NFR)
## Technical Requirements Specification

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 7.1. Performance

### 7.1.1. Page Load Performance

| Metric | Target | Measurement |
|--------|--------|-------------|
| **First Contentful Paint (FCP)** | < 1.5s | Lighthouse |
| **Largest Contentful Paint (LCP)** | < 2.5s | Lighthouse |
| **Time to Interactive (TTI)** | < 3.0s | Lighthouse |
| **Bundle Size (initial)** | < 500 KB (gzipped) | Build output |
| **Route-based Code Splitting** | Each route < 200 KB | Vite build |

### 7.1.2. Runtime Performance

| Metric | Target |
|--------|--------|
| **UI Response Time** | < 100ms for user interactions |
| **Task drag-and-drop** | 60 FPS smooth animation |
| **Modal open/close** | < 100ms animation |
| **Theme/language switch** | Instant (no page reload) |
| **Search/filter** | < 200ms debounced |

### 7.1.3. Lazy Loading Strategy

| Route | Strategy |
|-------|----------|
| `/app/projects/:id/chat` | Lazy load on first navigation |
| `/app/projects/:id/performance` | Lazy load on first navigation |
| `Document Viewer (DOCX/PDF)` | Lazy load viewer libraries |
| `docx-preview` | Dynamic import only when needed |
| `pdfjs-dist` | Dynamic import only when needed |

### 7.1.4. Image Optimization

| Rule | Implementation |
|------|---------------|
| Avatar images | Use `ui-avatars.com` API (SVG, scalable) |
| Document images | Display at appropriate container size |
| Icons | SVG via Lucide React (no raster images) |

---

## 7.2. Security

### 7.2.1. Authentication & Authorization

| Requirement | Implementation |
|-------------|----------------|
| **Password Storage** | bcrypt hash (cost factor 12) — Phase 2 |
| **Session Management** | JWT access token (15 min) + refresh token (7 days) |
| **CSRF Protection** | SameSite cookies + CSRF tokens |
| **XSS Prevention** | React auto-escaping; sanitize user-generated content |
| **SQL Injection** | ORM (Prisma/Drizzle) parameterized queries |

### 7.2.2. Access Control

| Requirement | Current State | Target (Phase 2) |
|-------------|--------------|-----------------|
| **Route Protection** | `ProtectedRoute` component | JWT middleware on API |
| **Role-based Access** | UI-level only (conditional rendering) | Server-side RBAC enforcement |
| **Resource Ownership** | N/A (mock) | Verify ownership before modify/delete |
| **Rate Limiting** | N/A | 100 requests/minute per user |

### 7.2.3. Data Security

| Requirement | Description |
|-------------|-------------|
| **HTTPS Only** | Enforce HTTPS in production |
| **Sensitive Data** | Never log passwords or tokens |
| **File Upload** | Validate MIME type + extension; scan for malware (Phase 2) |
| **File Size Limit** | Max 10 MB per file (enforced client + server) |
| **Allowed File Types** | DOC, DOCX, PDF, PPT, PPTX, PNG, JPG, ZIP |
| **Signed URLs** | File downloads via time-limited signed URLs (Phase 2) |

### 7.2.4. Security Headers

```
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' https://ui-avatars.com data:;
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

---

## 7.3. Scalability

### 7.3.1. User Scalability

| Scale | Target | Architecture |
|-------|--------|--------------|
| **Small (< 50 users)** | Current phase | Single server, mock data |
| **Medium (50–500 concurrent)** | Phase 2 | Horizontal scaling, Redis cache |
| **Large (500–5000 concurrent)** | Future | Load balancer + multiple servers |

### 7.3.2. Data Scalability

| Data Type | Current Strategy | Phase 2 Strategy |
|-----------|-----------------|-----------------|
| **User data** | In-memory mock | PostgreSQL with indexing |
| **Projects** | In-memory mock | Indexed by user_id + status |
| **Tasks** | In-memory mock | Indexed by project_id + status |
| **Chat messages** | In-memory mock | Paginated (50 per page), WebSocket |
| **Documents** | File references | S3 + DB metadata |

### 7.3.3. Code Splitting

```
Initial Bundle (critical path):
├── app shell (router, layouts)
├── auth pages
├── dashboard
└── project overview

Lazy Loaded:
├── /tasks     → TaskBoard, TaskModal, AddTaskModal
├── /documents → DocumentPage, DocxViewer, PdfViewer
├── /chat      → ChatPage, AIChatDialog
└── /performance → PerformancePage, ContributionGraph
```

---

## 7.4. Availability

### 7.4.1. Uptime Target

| Environment | Target | Notes |
|-------------|--------|-------|
| **Development** | N/A | Local only |
| **Staging** | 95% | For testing |
| **Production** | 99.5% | Monthly downtime < 3.6 hours |

### 7.4.2. Error Handling & Graceful Degradation

| Scenario | Handling |
|----------|----------|
| **Component render error** | ErrorBoundary wrapper per section |
| **API call failure (Phase 2)** | Toast error + retry option |
| **File preview unavailable** | Show file info + download link |
| **Chat connection lost** | Show "Disconnected" banner + auto-reconnect |
| **Empty data states** | EmptyState component with helpful message |

### 7.4.3. Health Check

```
GET /api/v1/health
Response 200:
{
  "status": "ok",
  "timestamp": "2026-05-29T10:00:00Z",
  "version": "1.0.0",
  "uptime": 86400
}
```

---

## 7.5. Browser Compatibility

### 7.5.1. Supported Browsers

| Browser | Minimum Version | Notes |
|---------|----------------|-------|
| **Chrome** | 90+ | Primary target |
| **Firefox** | 90+ | Full support |
| **Edge** | 90+ | Chromium-based, full support |
| **Safari** | 15+ | Full support |
| **Mobile Chrome** | 90+ | Responsive layout |
| **Mobile Safari** | 15+ | Responsive layout |

### 7.5.2. Feature Support

| Feature | Browser Support | Fallback |
|---------|---------------|---------|
| **CSS Grid** | All supported browsers | Flexbox fallback |
| **CSS Custom Properties** | All supported browsers | N/A |
| **ES2020+** | All supported browsers | N/A |
| **WebP Images** | Chrome 90+, Firefox 93+ | JPEG fallback |
| **WebSocket** | All supported browsers | Polling fallback |

---

## 7.6. Accessibility (WCAG 2.1 AA)

### 7.6.1. Requirements

| Category | Requirement |
|----------|------------|
| **Keyboard Navigation** | All interactive elements focusable; visible focus indicator |
| **Screen Reader** | Semantic HTML; ARIA labels on icons; alt text for images |
| **Color Contrast** | Text: 4.5:1 minimum; Large text: 3:1; UI elements: 3:1 |
| **Motion** | Respect `prefers-reduced-motion` |
| **Text Scaling** | UI readable up to 200% zoom without horizontal scroll |

### 7.6.2. Implementation Checklist

- [x] Semantic HTML (`<main>`, `<nav>`, `<button>`, `<header>`)
- [x] Keyboard-accessible buttons and links
- [x] Form labels associated with inputs
- [x] Toast notifications with role="alert"
- [x] Modal with focus trap
- [x] Loading skeletons for async content
- [x] Color contrast compliant (checked in Tailwind config)
- [ ] Full ARIA labels on all icon buttons
- [ ] `aria-expanded` on collapsible sections
- [ ] `prefers-reduced-motion` media query

---

## 7.7. Logging & Monitoring

### 7.7.1. Client-Side Logging (Phase 2)

```typescript
// Log levels
enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

// What to log
- Page views (route changes)
- User actions (click, submit, filter)
- API errors (4xx, 5xx responses)
- Performance metrics (LCP, FID, CLS)
- Unhandled exceptions
```

### 7.7.2. Server-Side Logging (Phase 2)

| Level | When |
|-------|-------|
| **DEBUG** | Request/response details (development only) |
| **INFO** | Successful operations (login, create, update) |
| **WARN** | Rate limit hit, validation failures |
| **ERROR** | Exceptions, database errors, third-party failures |

### 7.7.3. Metrics to Track

| Metric | Tool | Alert Threshold |
|--------|------|-----------------|
| **API Error Rate** | Prometheus + Grafana | > 1% |
| **P99 Latency** | APM | > 500ms |
| **CPU Usage** | Server monitoring | > 80% |
| **Memory Usage** | Server monitoring | > 85% |
| **Disk Usage** | Server monitoring | > 80% |

---

## 7.8. Backup & Recovery

### 7.8.1. Backup Strategy (Phase 2)

| Data Type | Backup Frequency | Retention | Method |
|-----------|-----------------|-----------|--------|
| **Database** | Daily + before major deployments | 30 days | pg_dump |
| **File Storage (S3)** | Versioning enabled | Indefinite | S3 versioning |
| **Config/secrets** | On change | 30 days | Encrypted backup |

### 7.8.2. Recovery Plan

| Scenario | RTO (Recovery Time Objective) | RPO (Recovery Point Objective) |
|----------|-------------------------------|--------------------------------|
| **Server crash** | < 30 minutes | < 1 hour |
| **Database corruption** | < 1 hour | < 24 hours |
| **Data loss** | < 2 hours | < 1 hour (incremental) |
| **Full region outage** | < 4 hours | < 1 hour |

---

## 7.9. Rate Limiting

### 7.9.1. API Rate Limits (Phase 2)

| Endpoint Group | Limit | Window |
|---------------|-------|--------|
| **Auth (login/register)** | 10 requests | Per minute |
| **General API** | 100 requests | Per minute |
| **File Upload** | 20 requests | Per minute |
| **Chat Messages** | 60 requests | Per minute |

### 7.9.2. Response Headers

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1623456789
```

### 7.9.3. Rate Limit Response (429)

```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMITED",
    "message": "Too many requests. Please try again in 60 seconds.",
    "retryAfter": 60
  }
}
```

---

## 7.10. Environment Variables

### 7.10.1. Frontend (.env)

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `VITE_API_URL` | Yes | `http://localhost:3000/api/v1` | Backend API URL |
| `VITE_APP_NAME` | No | `EZProject` | App display name |

### 7.10.2. Backend (Phase 2)

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `REDIS_URL` | No | Redis connection string |
| `JWT_SECRET` | Yes | Secret for JWT signing |
| `JWT_EXPIRES_IN` | No | Access token expiry (default: 15m) |
| `REFRESH_TOKEN_EXPIRES_IN` | No | Refresh token expiry (default: 7d) |
| `S3_BUCKET` | Yes | S3 bucket name |
| `S3_REGION` | Yes | AWS region |
| `S3_ACCESS_KEY` | Yes | AWS access key |
| `S3_SECRET_KEY` | Yes | AWS secret key |
| `FRONTEND_URL` | Yes | Frontend URL for CORS |
| `PORT` | No | Server port (default: 3000) |
| `NODE_ENV` | Yes | `development` / `production` |
