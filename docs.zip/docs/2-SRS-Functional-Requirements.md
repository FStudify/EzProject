# 2. SRS — Software Requirement Specification
## Functional Requirements Document

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 2.1. Authentication (Auth)

### 2.1.1. Login

| Field | Description |
|-------|-------------|
| **Description** | Cho phép người dùng đăng nhập vào hệ thống |
| **Input** | Username (string), Password (string) |
| **Output** | User object, redirect to Dashboard |
| **Validation** | Username và password không được rỗng; hiển thị lỗi nếu sai |
| **Demo** | Username: `user123`, Password: `123` |
| **Business Rules** | Lưu trạng thái đăng nhập vào localStorage; redirect về dashboard nếu đã login |
| **Edge Cases** | Sai password → hiển thị toast lỗi; tài khoản chưa đăng ký → redirect sang register |

### 2.1.2. Register

| Field | Description |
|-------|-------------|
| **Description** | Cho phép người dùng tạo tài khoản mới |
| **Input** | Full name, Email, Username, Password, Confirm Password |
| **Output** | User object mới, redirect to Login |
| **Validation** | Email phải hợp lệ; password phải khớp với confirm password |
| **Business Rules** | Kiểm tra email đã tồn tại chưa |
| **Edge Cases** | Email không hợp lệ; password không khớp |

### 2.1.3. Protected Route

| Field | Description |
|-------|-------------|
| **Description** | Route guard — chặn truy cập /app/* nếu chưa đăng nhập |
| **Behavior** | Chưa login → redirect /login; đã login → cho phép truy cập |
| **Edge Cases** | Token expired hoặc không hợp lệ |

### 2.1.4. Guest Route

| Field | Description |
|-------|-------------|
| **Description** | Route guard cho trang login/register |
| **Behavior** | Đã login → redirect /app; chưa login → cho phép truy cập login/register |

### 2.1.5. Logout

| Field | Description |
|-------|-------------|
| **Description** | Đăng xuất khỏi hệ thống |
| **Behavior** | Xóa user data khỏi localStorage, redirect /login |

---

## 2.2. Dashboard

### 2.2.1. Welcome Greeting

| Field | Description |
|-------|-------------|
| **Description** | Hiển thị lời chào theo thời điểm trong ngày |
| **Logic** | 5:00-11:59 → "Chào buổi sáng"; 12:00-17:59 → "Chào buổi chiều"; 18:00-4:59 → "Chào buổi tối" |
| **Output** | "Chào buổi [sáng/chiều/tối], [Tên user]!" |

### 2.2.2. Project Overview Cards

| Field | Description |
|-------|-------------|
| **Description** | Hiển thị danh sách project của user dưới dạng card |
| **Data** | Tên project, môn học, progress bar, deadline, avatar thành viên |
| **Behavior** | Click vào card → điều hướng đến project overview |
| **Filter** | Hiển thị active projects trước, completed sau |

### 2.2.3. Recent Activity Feed

| Field | Description |
|-------|-------------|
| **Description** | Danh sách hoạt động gần đây của các project |
| **Data** | Avatar user, action (uploaded/completed/updated/added), target name, timestamp |
| **Sorting** | Mới nhất lên đầu |

### 2.2.4. Upcoming Meetings Widget

| Field | Description |
|-------|-------------|
| **Description** | Hiển thị các cuộc họp sắp tới |
| **Data** | Tên cuộc họp, thời gian, địa điểm/link |

---

## 2.3. Projects

### 2.3.1. Project List

| Field | Description |
|-------|-------------|
| **Description** | Trang danh sách tất cả project của user |
| **Input** | Search query (optional) |
| **Output** | Grid/List các project card |
| **Filter** | By status (active/completed/archived) |
| **Sorting** | Mới nhất hoặc deadline gần nhất |

### 2.3.2. Project Overview (Detail)

| Field | Description |
|-------|-------------|
| **Description** | Trang chi tiết của một project |
| **Data** | Mô tả, progress, deadline, danh sách thành viên, thống kê task |
| **Navigation** | Tabs: Overview / Tasks / Documents / Members / Meetings / Chat / Performance |

### 2.3.3. Create Project

| Field | Description |
|-------|-------------|
| **Input** | Tên project, mô tả, môn học, deadline, danh sách thành viên |
| **Validation** | Tên project không được rỗng |
| **Output** | Project object mới, redirect đến project detail |

### 2.3.4. Project Roles

| Role | Permissions |
|------|------------|
| **leader** | CRUD all, manage members, delete project |
| **supervisor** | Edit tasks, upload documents, view all |
| **member** | Edit assigned tasks, upload documents, view all |

---

## 2.4. Tasks

### 2.4.1. Task Kanban Board

| Field | Description |
|-------|-------------|
| **Description** | Bảng Kanban với 5 cột trạng thái |
| **Columns** | Backlog, In Progress, Review, Done, On Hold |
| **Features** | Drag-and-drop task card giữa các cột; hiển thị số lượng task mỗi cột |
| **Card Info** | Tên task, assignee avatar, priority badge, deadline |
| **Input/Output** | Kéo thả task → cập nhật status |

### 2.4.2. Task Timeline View

| Field | Description |
|-------|-------------|
| **Description** | Hiển thị task theo timeline ngày |
| **Data** | Task name, assignee, start/deadline dates, progress bar |
| **Behavior** | Scroll ngang để xem timeline; click task → mở modal |

### 2.4.3. Add Task

| Field | Description |
|-------|-------------|
| **Input** | Title, description, assignee, priority (LOW/MEDIUM/HIGH), deadline |
| **Validation** | Title không rỗng; deadline phải là ngày tương lai |
| **Output** | Task object mới với status=BACKLOG |
| **Edge Cases** | Deadline trong quá khứ → warning nhưng cho phép tạo |

### 2.4.4. Task Modal (Detail View)

| Field | Description |
|-------|-------------|
| **Description** | Modal hiển thị chi tiết task |
| **Data** | Title, description, status, priority, assignee, deadline, comments |
| **Actions** | Edit task, change status, add comment, delete task |
| **Comments** | Author avatar, content, timestamp; supports @mention |

### 2.4.5. Task Filters

| Filter | Options |
|--------|---------|
| **By Member** | All / specific member |
| **By Priority** | All / HIGH / MEDIUM / LOW |
| **By Deadline** | Overdue / Due within N days / All |
| **By Status** | All / Backlog / In Progress / Review / Done / On Hold |

### 2.4.6. Task Priority & Status

| Priority | Visual |
|----------|--------|
| HIGH | Red badge |
| MEDIUM | Yellow/Orange badge |
| LOW | Gray badge |

| Status | Column |
|--------|--------|
| BACKLOG | Chưa bắt đầu |
| IN_PROGRESS | Đang làm |
| REVIEW | Đang xem xét |
| DONE | Hoàn thành |
| ON_HOLD | Tạm dừng |
| CANCELLED | Đã hủy |

### 2.4.7. Task Review Request

| Field | Description |
|-------|-------------|
| **Description** | Khi task ở Review status, cho phép nhận requestType=review |
| **Data** | requestNote — ghi chú tại sao cần review |
| **Flow** | Assignee gửi review request → Leader nhận notification → Approve/Reject |

---

## 2.5. Documents

### 2.5.1. Document Page

| Field | Description |
|-------|-------------|
| **Description** | Trang quản lý tài liệu với cấu trúc cây thư mục |
| **Layout** | Sidebar (folder tree) + Main (file list) + Detail panel |

### 2.5.2. Folder Management

| Action | Description |
|--------|-------------|
| **Create Folder** | Tạo thư mục mới trong thư mục hiện tại |
| **Rename Folder** | Đổi tên thư mục |
| **Delete Folder** | Xóa thư mục và toàn bộ file bên trong |
| **Navigate** | Click vào folder → hiển thị nội dung; nút "Up" → lên thư mục cha |

### 2.5.3. File Upload

| Field | Description |
|-------|-------------|
| **Description** | Tải file lên project |
| **Supported Types** | DOC, PDF, PPT, ZIP, IMG (PNG, JPG), OTHER |
| **Data** | Tên file, loại file (đoán từ extension), kích thước, người upload, ngày upload |
| **Validation** | Kích thước tối đa 10MB (mock) |
| **Edge Cases** | File trùng tên → cho phép upload (tạo bản sao) |

### 2.5.4. File Preview

| File Type | Viewer |
|-----------|--------|
| **DOC/DOCX** | docx-preview library (in-browser) |
| **PDF** | pdfjs-dist library (in-browser) |
| **IMG (PNG/JPG)** | Native `<img>` tag |
| **ZIP** | Hiển thị thông tin file, không preview |
| **PPT** | Hiển thị thông tin file, không preview |

### 2.5.5. File Operations

| Action | Description |
|--------|-------------|
| **Rename** | Đổi tên file |
| **Delete** | Xóa file khỏi project |
| **Download** | Tải file về máy (mock — simulated) |
| **Search** | Tìm kiếm file theo tên |

### 2.5.6. Document Comments

| Field | Description |
|-------|-------------|
| **Description** | Bình luận trên document |
| **Data** | Author, content, timestamp |
| **Features** | @mention support (hiển thị nhưng chưa có notification) |

---

## 2.6. Members

### 2.6.1. Member List

| Field | Description |
|-------|-------------|
| **Description** | Danh sách thành viên trong project |
| **Data** | Avatar, tên, email, vai trò, số task đang làm |
| **Role Badges** | Leader (crown icon), Supervisor, Member |

### 2.6.2. Role Management

| Action | Description |
|--------|-------------|
| **Change Role** | Leader có thể thay đổi vai trò member ↔ supervisor |
| **Invite Member** | Tạo invite link cho thành viên mới |
| **Remove Member** | Xóa thành viên khỏi project (chỉ leader) |
| **Constraint** | Không thể hạ vai trò owner (người tạo project) |

### 2.6.3. Member Actions

| Action | Description |
|--------|-------------|
| **Edit Info** | Chỉnh sửa tên và email thành viên |
| **Remove from Project** | Xóa thành viên (leader only) |
| **Copy Invite Link** | Sao chép link mời thành viên |

---

## 2.7. Meetings

### 2.7.1. Meeting List

| Field | Description |
|-------|-------------|
| **Description** | Danh sách cuộc họp của project |
| **Data** | Tên, thời gian, địa điểm/link, số người tham gia, trạng thái |
| **Filter** | By status: Scheduled, In Progress, Completed, Cancelled |

### 2.7.2. Schedule Meeting

| Field | Description |
|-------|-------------|
| **Input** | Tiêu đề, mô tả, loại (online/offline), ngày/giờ bắt đầu, thời lượng, địa điểm hoặc link, danh sách attendees |
| **Validation** | Tiêu đề không rỗng; thời gian bắt đầu phải là tương lai |
| **Online** | Hiển thị trường meetingLink (Zoom, Meet, v.v.) |
| **Offline** | Hiển thị trường location (địa chỉ) |

### 2.7.3. RSVP / Attendee Response

| Response | Description |
|----------|-------------|
| **Will Attend** | Xác nhận tham gia |
| **Decline** | Từ chối + optional reason |

### 2.7.4. Meeting Status Flow

```
Scheduled → (start time reached) → In Progress → (end time) → Completed
    ↓
(Cancelled by organizer)
```

### 2.7.5. Meeting Actions

| Action | Description |
|--------|-------------|
| **Join** | Online meeting → mở link trong tab mới |
| **Decline** | Gửi lý do từ chối |
| **Edit** | Chỉnh sửa thông tin cuộc họp (organizer only) |
| **Delete** | Xóa cuộc họp (organizer only) |
| **Create Task from Meeting** | Tạo task follow-up từ cuộc họp |

---

## 2.8. Chat

### 2.8.1. Chat Page

| Field | Description |
|-------|-------------|
| **Description** | Giao diện chat chính với danh sách phòng + message panel |
| **Layout** | Left sidebar (room list) + Right panel (messages) |

### 2.8.2. Chat Room Types

| Type | Description | Example |
|------|-------------|---------|
| **general** | Phòng chung của project | General |
| **channel** | Kênh team (Frontend, Backend, Design) | Frontend Team |
| **direct** | Tin nhắn trực tiếp 1-1 | Bob Chen |

### 2.8.3. Message Features

| Feature | Description |
|---------|-------------|
| **Send Message** | Gửi tin nhắn với nội dung text |
| **Timestamps** | Hiển thị thời gian gửi |
| **Sender Info** | Avatar + tên người gửi |
| **AI Messages** | Tin nhắn từ AI assistant (sender='ai') |

### 2.8.4. Channel Management

| Action | Description |
|--------|-------------|
| **Create Channel** | Tạo kênh mới với tên và danh sách thành viên |
| **Rename Channel** | Đổi tên kênh (không áp dụng cho general) |
| **Delete Channel** | Xóa kênh (không áp dụng cho general) |
| **Leave Channel** | Rời khỏi kênh |

### 2.8.5. AI Assistant Chat

| Field | Description |
|-------|-------------|
| **Description** | Dialog AI trả lời câu hỏi về project management |
| **Trigger** | Icon AI trong chat page |
| **Topics** | Deadline, progress, task, priority, schedule, tips, reports |
| **Behavior** | Match từ khóa → trả lời từ mockAIResponses |

### 2.8.6. Chat Message Channels

| Channel | Description |
|---------|-------------|
| **group** | Tin nhắn thông thường trong phòng |
| **task** | Thảo luận về một task cụ thể |
| **document** | Thảo luận về một document cụ thể |
| **ai** | Tin nhắn từ AI assistant |

---

## 2.9. Performance

### 2.9.1. Performance Overview

| Field | Description |
|-------|-------------|
| **Description** | Trang tổng hợp hiệu suất của tất cả thành viên trong project |
| **Data** | Score, tasks completed/in-progress/todo, documents uploaded, comments count |

### 2.9.2. Contribution Graph

| Field | Description |
|-------|-------------|
| **Description** | GitHub-style contribution heatmap |
| **Data** | Date (daily) → contribution count (0-6) |
| **Color Scale** | 0 = gray, 1-2 = light green, 3-4 = medium green, 5-6 = dark green |
| **Range** | 3 tháng gần nhất |
| **Calculation** | Determined by member index + day index for deterministic variation |

### 2.9.3. Member Evaluation

| Field | Description |
|-------|-------------|
| **Description** | Cho phép leader/supervisor đánh giá member |
| **Input** | Rating (1-5 stars), Feedback text |
| **Output** | Lưu evaluation vào member record |
| **Constraint** | Chỉ leader/supervisor mới có quyền đánh giá |

### 2.9.4. Member Performance Card

| Data | Description |
|------|-------------|
| **Tasks** | Completed / In Progress / Todo / Overdue |
| **Documents** | Số file đã upload |
| **Comments** | Số bình luận đã viết |
| **Score** | Điểm tổng hợp (0-100) |

---

## 2.10. Profile & Settings

### 2.10.1. Profile Page

| Field | Description |
|-------|-------------|
| **Data** | Avatar, tên, email, department, position, phone, bio |
| **Actions** | Edit profile, save changes |

### 2.10.2. Settings Page

| Setting | Options |
|---------|---------|
| **Theme** | Light / Dark (default: Light) |
| **Language** | Tiếng Việt / English (default: Tiếng Việt) |
| **Notifications** | Toggle notification preferences (mock) |
| **Account** | Account management links |

---

## 2.11. Notifications

### 2.11.1. Notification Types

| Type | Description |
|------|-------------|
| **task** | Task được giao, deadline sắp đến, task được duyệt/từ chối |
| **meeting** | Cuộc họp sắp diễn ra |
| **chat** | Được nhắc trong chat (@mention) |
| **document** | Tài liệu mới được upload |

### 2.11.2. Notification Behavior

| Action | Description |
|--------|-------------|
| **Display** | Badge count trên icon bell (unread only) |
| **Drawer** | Click bell → hiển thị notification drawer |
| **Mark All Read** | Đánh dấu tất cả là đã đọc |
| **Link** | Click notification → navigate đến relevant page |

---

## 2.12. Theme & Language

### 2.12.1. Theme Toggle

| Field | Description |
|-------|-------------|
| **Options** | Light, Dark |
| **Implementation** | Toggle `html.dark` class; lưu preference vào localStorage |
| **CSS** | Tailwind v4 dark mode với class strategy |

### 2.12.2. Language Switch

| Field | Description |
|-------|-------------|
| **Options** | Vietnamese (vi), English (en) |
| **Implementation** | Context-based translation với `t()` function |
| **Persistence** | Lưu preference vào localStorage |

---

## 2.13. Landing Page

| Section | Description |
|---------|-------------|
| **Hero** | Badge, title, description, CTA buttons |
| **Features** | 6 feature cards (Tasks, Team, Progress, Meetings, Docs, Chat) |
| **Stats** | Tasks completed, Active projects, Team progress |
| **Footer** | Tagline, build credit |
| **Navigation** | Login, Register buttons |

---

## 2.14. Error Handling Summary

| Scenario | Handling |
|----------|----------|
| Invalid login credentials | Toast error: "Sai tên đăng nhập hoặc mật khẩu" |
| Empty required fields | Inline validation message |
| File upload failure | Toast error: "Tải file thất bại" |
| Task not found | Redirect về task list với toast |
| Network error (future) | Toast error: "Lỗi kết nối. Vui lòng thử lại" |
| Unauthorized access | Redirect to login |

---

## 2.15. Permission Matrix

| Action | Leader | Supervisor | Member |
|--------|--------|-----------|--------|
| View project | ✓ | ✓ | ✓ |
| Create task | ✓ | ✓ | ✓ |
| Edit own task | ✓ | ✓ | ✓ |
| Edit any task | ✓ | ✓ | ✗ |
| Delete task | ✓ | ✗ | ✗ |
| Change member role | ✓ | ✗ | ✗ |
| Remove member | ✓ | ✗ | ✗ |
| Evaluate member | ✓ | ✓ | ✗ |
| Schedule meeting | ✓ | ✓ | ✓ |
| Delete meeting | ✓ (organizer) | ✗ | ✗ |
| Delete project | ✓ | ✗ | ✗ |
