# 6. System Architecture
## Architecture Design for EZProject

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 6.1. Architecture Overview

EZProject sử dụng kiến trúc **Client-Server** với split rõ ràng giữa Frontend (Client) và Backend (Server).

### Current State (v1.0 — Frontend Only)
Dự án hiện tại là **Single Page Application (SPA)** với mock data tất cả ở phía client.

```
┌─────────────────────────────────────────────────────┐
│                    Client Browser                     │
│                                                     │
│  ┌─────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │  React   │  │   Vite   │  │  localStorage    │  │
│  │   App     │──│  Build   │  │  (mock data +   │  │
│  │  (SPA)   │  │  Tool    │  │   auth state)    │  │
│  └─────────┘  └──────────┘  └──────────────────┘  │
│                                                     │
│  React Router ──▶ Pages / Features / Components     │
│  Tailwind CSS  ──▶ Styling                         │
│  Context API  ──▶ State Management                  │
└─────────────────────────────────────────────────────┘
```

### Target State (Phase 2 — With Backend)
```
┌─────────────────────────────────────────────────────────────┐
│                      Client Browser                          │
│  ┌─────────────────────────────────────────────────────┐    │
│  │               React SPA (Vite + Tailwind)            │    │
│  │  Router ──▶ Pages ──▶ Features ──▶ Components      │    │
│  │  Context ──▶ Auth / Theme / Language State         │    │
│  └──────────────────────┬──────────────────────────────┘    │
└──────────────────────────┼──────────────────────────────────┘
                           │ HTTPS
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                    Load Balancer (nginx)                     │
└──────────────────────────┬──────────────────────────────────┘
                           │
         ┌─────────────────┴─────────────────┐
         ▼                                   ▼
┌─────────────────────┐         ┌─────────────────────┐
│   Web Server        │         │   WebSocket Server   │
│   (Node.js/Express  │         │   (Socket.io)       │
│    hoặc NestJS)     │         │   cho Chat realtime  │
│                     │         │                     │
│  ┌──────────────┐  │         │                     │
│  │  Auth        │  │         │                     │
│  │  Middleware  │  │         │                     │
│  └──────┬───────┘  │         │                     │
│         │          │         │                     │
│  ┌──────┴───────┐  │         │                     │
│  │  Controllers  │  │         │                     │
│  │  /api/v1/*   │◀─┼─────────┼─────────────────────┘
│  └──────┬───────┘  │         │
│         │          │         │
│  ┌──────┴───────┐  │         │
│  │   Services   │  │         │
│  └──────┬───────┘  │         │
│         │          │         │
└─────────┼──────────┴─────────┘
          │
    ┌─────┴─────┐
    │            │
    ▼            ▼
┌────────┐  ┌─────────┐  ┌──────────┐  ┌──────────┐
│  Redis │  │PostgreSQL│  │  S3/Blob │  │  Email   │
│ Cache  │  │   DB    │  │ Storage  │  │ Service  │
│        │  │         │  │          │  │          │
└────────┘  └─────────┘  └──────────┘  └──────────┘
```

---

## 6.2. Frontend Architecture

### 6.2.1. Component Hierarchy

```
App (App.tsx)
├── AuthProvider (AuthContext)
├── ThemeProvider (ThemeContext)
├── LanguageProvider (LanguageContext)
├── ToastProvider (ToastContext)
└── RouterProvider (React Router)
    │
    ├── LandingPage (/)
    │
    ├── GuestRoute
    │   ├── LoginPage (/login)
    │   └── RegisterPage (/register)
    │
    └── ProtectedRoute
        └── AppLayout
            ├── Topbar
            │   ├── Logo
            │   ├── SearchBar
            │   ├── LanguageSwitcher
            │   ├── ThemeToggle
            │   ├── NotificationBell
            │   │   └── NotificationDrawer
            │   └── UserMenu
            │
            ├── Sidebar (collapsible)
            │   ├── Dashboard Link
            │   ├── Settings Link
            │   ├── Profile Link
            │   └── ProjectList
            │       └── ProjectNavItem[] (expandable)
            │
            └── Routes
                ├── /app → DashboardPage
                ├── /app/profile → ProfilePage
                ├── /app/settings → SettingsPage
                ├── /app/projects → ProjectListPage
                │
                └── /app/projects/:projectId → ProjectLayout
                    ├── ProjectTopbar
                    └── Routes
                        ├── / → ProjectOverview
                        ├── /tasks → TaskBoard (Kanban + Timeline)
                        ├── /documents → DocumentPage
                        ├── /members → MemberList
                        ├── /meetings → MeetingList
                        ├── /chat → ChatPage
                        │   ├── ChatSidebar (rooms list)
                        │   └── ChatPanel (messages + AI dialog)
                        └── /performance → PerformancePage
```

### 6.2.2. Feature Module Structure

Mỗi feature module tuân theo cấu trúc thống nhất:

```
features/
├── auth/
│   ├── index.ts              (barrel export)
│   ├── AuthContext.tsx       (auth state management)
│   ├── authService.ts        (login/register API calls)
│   ├── LoginPage.tsx
│   ├── RegisterPage.tsx
│   ├── LoginForm.tsx
│   ├── BrandingPanel.tsx
│   ├── DemoAccountBox.tsx
│   ├── ProtectedRoute.tsx
│   └── GuestRoute.tsx
│
├── tasks/
│   ├── index.ts
│   ├── TaskBoard.tsx         (Kanban board)
│   ├── TaskColumn.tsx        (single column)
│   ├── TaskCard.tsx          (task card)
│   ├── TaskTimeline.tsx      (timeline view)
│   ├── TaskModal.tsx         (detail modal)
│   ├── AddTaskModal.tsx      (create task)
│   └── TaskFormControls.tsx  (form components)
```

### 6.2.3. State Management Architecture

```
┌────────────────────────────────────────────────────────┐
│                  Application State                      │
├────────────────────────────────────────────────────────┤
│                                                        │
│  AuthContext (global)                                  │
│  ├── user: User | null                                │
│  ├── login(username, password)                        │
│  ├── register(...)                                    │
│  └── logout()                                         │
│                                                        │
│  ThemeContext (global)                                 │
│  ├── theme: 'light' | 'dark'                         │
│  ├── toggleTheme()                                    │
│  └── Effect: toggle html.dark class                  │
│                                                        │
│  LanguageContext (global)                              │
│  ├── lang: 'vi' | 'en'                               │
│  ├── t(key): string                                   │
│  └── setLang(lang)                                    │
│                                                        │
│  ToastContext (global)                                │
│  ├── showToast(type, message)                        │
│  └── ToastProvider renders toasts                    │
│                                                        │
│  LocalStorage Persistence                              │
│  ├── 'ez_user'    → Auth user data                   │
│  ├── 'ez_theme'   → 'light' | 'dark'                │
│  └── 'ez_lang'    → 'vi' | 'en'                    │
│                                                        │
└────────────────────────────────────────────────────────┘
```

---

## 6.3. Backend Architecture (Phase 2 Plan)

### 6.3.1. Layered Architecture

```
┌────────────────────────────────────────┐
│         Presentation Layer              │
│  (Controllers / Route Handlers)         │
│  - Input validation                     │
│  - Response formatting                  │
│  - HTTP status codes                    │
└────────────────┬───────────────────────┘
                 │
┌────────────────▼───────────────────────┐
│          Service Layer                 │
│  - Business logic                      │
│  - Authorization checks                 │
│  - Data transformation                 │
└────────────────┬───────────────────────┘
                 │
┌────────────────▼───────────────────────┐
│        Repository Layer                 │
│  (Database access via Prisma/Drizzle)  │
│  - CRUD operations                     │
│  - Queries                             │
└────────────────┬───────────────────────┘
                 │
┌────────────────▼───────────────────────┐
│          Data Layer                    │
│  - PostgreSQL                          │
│  - Redis (cache)                       │
│  - S3 (file storage)                   │
└────────────────────────────────────────┘
```

### 6.3.2. Module Structure (NestJS suggested)

```
src/
├── modules/
│   ├── auth/
│   │   ├── auth.controller.ts
│   │   ├── auth.service.ts
│   │   ├── auth.module.ts
│   │   ├── strategies/
│   │   └── guards/
│   │
│   ├── users/
│   │   ├── users.controller.ts
│   │   ├── users.service.ts
│   │   └── users.module.ts
│   │
│   ├── projects/
│   │   ├── projects.controller.ts
│   │   ├── projects.service.ts
│   │   └── projects.module.ts
│   │
│   ├── tasks/
│   │   ├── tasks.controller.ts
│   │   ├── tasks.service.ts
│   │   └── tasks.module.ts
│   │
│   ├── documents/
│   │   ├── documents.controller.ts
│   │   ├── documents.service.ts
│   │   └── documents.module.ts
│   │
│   ├── meetings/
│   │   ├── meetings.controller.ts
│   │   ├── meetings.service.ts
│   │   └── meetings.module.ts
│   │
│   ├── chat/
│   │   ├── chat.gateway.ts   (WebSocket)
│   │   ├── chat.service.ts
│   │   └── chat.module.ts
│   │
│   ├── notifications/
│   │   ├── notifications.controller.ts
│   │   ├── notifications.service.ts
│   │   └── notifications.module.ts
│   │
│   └── performance/
│       ├── performance.controller.ts
│       ├── performance.service.ts
│       └── performance.module.ts
│
├── common/
│   ├── filters/       (exception filters)
│   ├── guards/        (auth guards, roles guards)
│   ├── interceptors/  (logging, transform)
│   ├── decorators/    (@Public, @Roles, etc.)
│   └── pipes/          (validation pipes)
│
├── prisma/
│   └── schema.prisma
│
└── main.ts
```

---

## 6.4. Third-Party Integrations

| Service | Purpose | Integration |
|---------|---------|-------------|
| **ui-avatars.com** | Generate user avatar from initials | Direct URL: `https://ui-avatars.com/api/?name=...` |
| **pdfjs-dist** | PDF rendering in browser | NPM package |
| **docx-preview** | DOCX rendering in browser | NPM package |
| **Google Fonts** | Typography (Inter, Be Vietnam Pro) | CDN link in index.html |

### Future Integrations (Phase 2)

| Service | Purpose | Notes |
|---------|---------|-------|
| **Firebase / FCM** | Push Notifications | For mobile & web |
| **SendGrid / SES** | Email Notifications | Task due, meeting reminder |
| **AWS S3 / MinIO** | File Storage | Upload & serve documents |
| **Google Meet / Zoom API** | Video Conferencing | Meeting integration |

---

## 6.5. Security Architecture

```
┌─────────────────────────────────────────────┐
│              Security Layers                  │
├─────────────────────────────────────────────┤
│                                              │
│  1. Transport Layer                          │
│     HTTPS only (TLS 1.2+)                    │
│     HSTS headers                             │
│                                              │
│  2. Authentication                           │
│     JWT Access Token (15 min expiry)         │
│     Refresh Token (7 days, stored in DB)     │
│     Password: bcrypt hashing (cost factor 12)│
│                                              │
│  3. Authorization                            │
│     RBAC: leader / supervisor / member       │
│     Resource-level permission checks          │
│     Project membership verification            │
│                                              │
│  4. Input Validation                         │
│     Zod schema validation (API)              │
│     React form validation (FE)                │
│     XSS sanitization                          │
│                                              │
│  5. API Security                             │
│     Rate limiting (100 req/min per user)     │
│     CORS whitelist                           │
│     Helmet.js security headers               │
│                                              │
│  6. Data Security                            │
│     SQL injection prevention (ORM)            │
│     File upload validation (type + size)     │
│     Signed URLs for file downloads            │
│                                              │
└─────────────────────────────────────────────┘
```

---

## 6.6. Deployment Architecture (Phase 2)

### 6.6.1. Infrastructure Overview

```
                    ┌─────────────────┐
                    │  CDN (Cloudflare │
                    │   hoặc AWS      │
                    │   CloudFront)   │
                    └────────┬────────┘
                             │ Static files (dist/)
                             │
                    ┌────────▼────────┐
                    │  Load Balancer   │
                    │  (nginx/SG)     │
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
     ┌────────▼────────┐         ┌────────▼────────┐
     │   App Server 1   │         │   App Server 2   │
     │  (Node.js/Nest)  │         │  (Node.js/Nest)  │
     └────────┬────────┘         └────────┬────────┘
              │                           │
              └──────────────┬──────────────┘
                             │
        ┌───────────────────┼───────────────────┐
        │                   │                    │
┌───────▼───────┐  ┌────────▼──────┐  ┌────────▼────────┐
│  PostgreSQL   │  │    Redis      │  │     S3 / MinIO   │
│   Primary     │  │    Cache      │  │   File Storage   │
│   + Replica  │  │               │  │                  │
└──────────────┘  └───────────────┘  └──────────────────┘
```

### 6.6.2. Docker Compose (Development)

```yaml
version: '3.8'
services:
  frontend:
    build: ./frontend
    ports:
      - "5173:5173"
    volumes:
      - ./frontend:/app
      - /app/node_modules
    environment:
      - VITE_API_URL=http://localhost:3000/api/v1

  api:
    build: ./backend
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgresql://postgres:password@db:5432/ezproject
      - REDIS_URL=redis://cache:6379
      - JWT_SECRET=...
      - FRONTEND_URL=http://localhost:5173
    depends_on:
      - db
      - cache

  db:
    image: postgres:15
    environment:
      POSTGRES_DB: ezproject
      POSTGRES_PASSWORD: password
    volumes:
      - pgdata:/var/lib/postgresql/data

  cache:
    image: redis:7-alpine
    volumes:
      - redisdata:/data

volumes:
  pgdata:
  redisdata:
```

---

## 6.7. CI/CD Pipeline

```
┌──────────────────────────────────────────────────────────────────┐
│                        CI/CD Flow                                 │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  Developer push ──▶ GitHub Actions                                │
│                                                                   │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌───────────┐ │
│  │  Lint &   │─▶│  Type      │─▶│  Build     │─▶│  Test     │ │
│  │  Format   │  │  Check     │  │  (Vite)   │  │  (Vitest) │ │
│  │  (ESLint) │  │  (tsc)    │  │           │  │           │ │
│  └────────────┘  └────────────┘  └────────────┘  └───────────┘ │
│                                                         │        │
│                                                         ▼        │
│                                                  ┌───────────┐   │
│                                                  │  Deploy   │   │
│                                                  │  to Staging│  │
│                                                  └───────────┘   │
│                                                         │        │
│                                                         ▼        │
│                                                  ┌───────────┐   │
│                                                  │  E2E Test  │  │
│                                                  │  (Playwright)│ │
│                                                  └───────────┘   │
│                                                         │        │
│                                                         ▼        │
│                                                  ┌───────────┐   │
│                                                  │  Deploy   │   │
│                                                  │  to Prod  │   │
│                                                  └───────────┘   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 6.8. File Upload & Storage Flow

```
User uploads file
      │
      ▼
┌──────────────┐
│   Browser    │
│  (Frontend)  │
└──────┬───────┘
       │ POST /api/v1/projects/:id/documents/upload
       │ (multipart/form-data)
       ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   API        │───▶│   Validate   │───▶│  Save file  │
│   Server     │    │   (type,    │    │  to S3/MinIO│
│              │    │   size)     │    │             │
└──────┬───────┘    └──────────────┘    └──────┬───────┘
       │                                        │
       │ Save document record to DB             │
       ▼                                        │
┌──────────────┐                                │
│  PostgreSQL  │                                │
│  (metadata) │                                │
└──────────────┘                                │
       │                                        │
       └──────────┐     ┌────────────────────────┘
                  │     │ Generate signed URL (1 hour expiry)
                  ▼     ▼
           ┌──────────────┐
           │   Client     │
           │  downloads   │
           │  via signed  │
           │  URL         │
           └──────────────┘
```
