# 3. Use Case & User Flow
## System Interaction Specification

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 3.1. Use Case Diagram

```
                          ┌──────────────────────────────────────────┐
                          │           EZProject System                │
                          │                                          │
                          │  ┌────────────┐    ┌────────────────┐   │
┌─────────────┐          │  │  Dashboard │    │  Project Mgmt  │   │
│   Visitor   │──────────▶│  │  (View     │    │  (CRUD Project)│   │
│ (Landing)  │          │  │   Overview) │    └────────────────┘   │
└─────────────┘          │  └────────────┘                         │
                        │       │                                  │
                        │       ▼                                  │
                        │  ┌────────────┐    ┌────────────────┐   │
┌─────────────┐          │  │  Task Mgmt │    │  Document Mgmt │   │
│   Student  │──────────▶│  │  (Kanban/  │    │  (Upload/      │   │
│  (Member)  │          │  │   Timeline)│    │   Preview)     │   │
└─────────────┘          │  └────────────┘    └────────────────┘   │
                        │       │                                  │
                        │       ▼                                  │
┌─────────────┐          │  ┌────────────┐    ┌────────────────┐   │
│   Team     │──────────▶│  │   Meeting  │    │     Chat       │   │
│  Leader    │          │  │   Mgmt     │    │  (Channel/DM/  │   │
│            │          │  │ (Schedule/ │    │   AI)           │   │
└─────────────┘          │  │   RSVP)    │    └────────────────┘   │
                        │  └────────────┘                         │
                        │                                          │
                        │       │                                  │
                        │       ▼                                  │
                        │  ┌────────────┐    ┌────────────────┐   │
                        │  │ Performance│    │  Auth System   │   │
                        │  │  Tracking  │    │  (Login/Reg/   │   │
                        │  └────────────┘    │   Logout)       │   │
                        │                  └────────────────┘   │
                        └──────────────────────────────────────────┘
```

---

## 3.2. Actor Definitions

| Actor | Description |
|-------|-------------|
| **Visitor** | Người dùng chưa đăng nhập, xem được Landing Page |
| **Student (Member)** | Người dùng đã đăng nhập, có thể tham gia project và thực hiện các tác vụ cơ bản |
| **Team Leader** | Thành viên có vai trò leader trong một project, có toàn quyền quản lý |
| **Supervisor** | Thành viên có vai trò supervisor, có quyền đánh giá và giám sát |
| **AI Assistant** | Actor hệ thống, trả lời câu hỏi về project management |

---

## 3.3. Use Cases

### UC-01: Đăng nhập hệ thống

| Field | Description |
|-------|-------------|
| **UC ID** | UC-01 |
| **Actor** | Visitor |
| **Trigger** | Click "Đăng nhập" trên Landing Page |
| **Precondition** | Người dùng chưa đăng nhập |

**Main Flow:**
1. Hệ thống hiển thị trang Login
2. Người dùng nhập username và password
3. Người dùng click "Đăng nhập"
4. Hệ thống xác thực credentials
5. Hệ thống lưu user vào localStorage
6. Hệ thống chuyển hướng đến Dashboard

**Alternative Flow:**
- A1: Credentials sai → Hiển thị toast lỗi, quay lại bước 2
- A2: Click "Tài khoản demo" → Điền username/password demo và submit

**Exception Flow:**
- E1: Trường rỗng → Hiển thị validation message

---

### UC-02: Đăng ký tài khoản

| Field | Description |
|-------|-------------|
| **UC ID** | UC-02 |
| **Actor** | Visitor |
| **Trigger** | Click "Đăng ký" trên Login page |
| **Precondition** | Người dùng chưa có tài khoản |

**Main Flow:**
1. Hệ thống hiển thị trang Register
2. Người dùng nhập full name, email, username, password, confirm password
3. Người dùng click "Đăng ký"
4. Hệ thống tạo tài khoản mới
5. Hệ thống chuyển hướng đến Login

**Alternative Flow:**
- A1: Email không hợp lệ → Hiển thị lỗi validation
- A2: Password không khớp → Hiển thị lỗi "Mật khẩu không khớp"

---

### UC-03: Xem Dashboard

| Field | Description |
|-------|-------------|
| **UC ID** | UC-03 |
| **Actor** | Student |
| **Trigger** | Truy cập /app sau khi đăng nhập |
| **Precondition** | Người dùng đã đăng nhập |

**Main Flow:**
1. Hệ thống tải thông tin user và projects
2. Hệ thống hiển thị lời chào theo thời điểm
3. Hệ thống hiển thị danh sách project cards
4. Hệ thống hiển thị activity feed
5. Hệ thống hiển thị upcoming meetings

---

### UC-04: Tạo Project mới

| Field | Description |
|-------|-------------|
| **UC ID** | UC-04 |
| **Actor** | Student |
| **Trigger** | Click "Tạo dự án" trên Dashboard |
| **Precondition** | Người dùng đã đăng nhập |

**Main Flow:**
1. Hệ thống hiển thị form tạo project
2. Người dùng nhập tên, mô tả, môn học, deadline
3. Người dùng chọn thành viên (tùy chọn)
4. Người dùng click "Tạo"
5. Hệ thống tạo project mới
6. Hệ thống chuyển hướng đến project overview

---

### UC-05: Quản lý Công việc (Kanban)

| Field | Description |
|-------|-------------|
| **UC ID** | UC-05 |
| **Actor** | Student |
| **Trigger** | Truy cập /projects/:id/tasks |
| **Precondition** | Đang trong một project |

**Main Flow:**
1. Hệ thống hiển thị bảng Kanban với 5 cột
2. Mỗi cột hiển thị task cards
3. Người dùng kéo thả task sang cột khác
4. Hệ thống cập nhật task status

**Alternative Flow:**
- A1: Click "Thêm công việc" → Mở form tạo task
- A2: Click task card → Mở Task Modal

---

### UC-06: Tạo Công việc mới

| Field | Description |
|-------|-------------|
| **UC ID** | UC-06 |
| **Actor** | Student |
| **Trigger** | Click "Thêm công việc" trên Task Board |
| **Precondition** | Đang ở trang Tasks |

**Main Flow:**
1. Hệ thống hiển thị form AddTaskModal
2. Người dùng nhập title, description, assignee, priority, deadline
3. Người dùng click "Lưu"
4. Hệ thống tạo task mới với status=BACKLOG
5. Task mới xuất hiện trong cột Backlog

---

### UC-07: Upload Tài liệu

| Field | Description |
|-------|-------------|
| **UC ID** | UC-07 |
| **Actor** | Student |
| **Trigger** | Click "Tải lên" trong Documents page |
| **Precondition** | Đang ở trang Documents của một project |

**Main Flow:**
1. Hệ thống hiển thị file picker
2. Người dùng chọn file
3. Hệ thống xác định loại file từ extension
4. Hệ thống tạo document record
5. File xuất hiện trong danh sách

**Alternative Flow:**
- A1: Upload DOCX/PDF → Có thể xem preview sau khi upload

---

### UC-08: Lên lịch Cuộc họp

| Field | Description |
|-------|-------------|
| **UC ID** | UC-08 |
| **Actor** | Student |
| **Trigger** | Click "Lên lịch họp" trên Meetings page |
| **Precondition** | Đang ở trang Meetings |

**Main Flow:**
1. Hệ thống hiển thị form tạo meeting
2. Người dùng nhập tiêu đề, loại (online/offline), thời gian
3. Người dùng chọn attendees
4. Người dùng click "Tạo"
5. Hệ thống tạo meeting và gửi notification cho attendees

---

### UC-09: RSVP Cuộc họp

| Field | Description |
|-------|-------------|
| **UC ID** | UC-09 |
| **Actor** | Student |
| **Trigger** | Click button "Tham gia" hoặc "Không tham gia" trên meeting |
| **Precondition** | Có meeting được mời tham gia |

**Main Flow:**
1. Người dùng xem chi tiết meeting
2. Người dùng click "Tham gia" hoặc "Không tham gia"
3. Hệ thống cập nhật attendeeResponse
4. Hệ thống hiển thị cập nhật trên UI

---

### UC-10: Trò chuyện trong Kênh

| Field | Description |
|-------|-------------|
| **UC ID** | UC-10 |
| **Actor** | Student |
| **Trigger** | Truy cập /projects/:id/chat |
| **Precondition** | Đang trong một project |

**Main Flow:**
1. Hệ thống hiển thị danh sách phòng chat
2. Người dùng chọn một phòng
3. Hệ thống hiển thị tin nhắn của phòng đó
4. Người dùng nhập tin nhắn và gửi
5. Hệ thống thêm tin nhắn vào danh sách

**Alternative Flow:**
- A1: Click tab "Kênh" → Hiển thị danh sách channels
- A2: Click tab "Tin nhắn trực tiếp" → Hiển thị danh sách DM

---

### UC-11: Chat với AI Assistant

| Field | Description |
|-------|-------------|
| **UC ID** | UC-11 |
| **Actor** | Student |
| **Trigger** | Click icon AI trong Chat page |
| **Precondition** | Đang ở Chat page |

**Main Flow:**
1. Hệ thống hiển thị AI Chat Dialog
2. Người dùng nhập câu hỏi
3. Hệ thống match từ khóa với mockAIResponses
4. Hệ thống hiển thị câu trả lời

---

### UC-12: Xem Hiệu suất Thành viên

| Field | Description |
|-------|-------------|
| **UC ID** | UC-12 |
| **Actor** | Student, Leader, Supervisor |
| **Trigger** | Truy cập /projects/:id/performance |
| **Precondition** | Đang trong một project |

**Main Flow:**
1. Hệ thống hiển thị danh sách member performance cards
2. Mỗi card hiển thị score, tasks, contribution graph
3. Leader/Supervisor có thể click "Đánh giá" để nhập rating và feedback

---

### UC-13: Chuyển đổi Theme

| Field | Description |
|-------|-------------|
| **UC ID** | UC-13 |
| **Actor** | Student |
| **Trigger** | Toggle switch trong Settings |
| **Precondition** | Đã đăng nhập |

**Main Flow:**
1. Người dùng vào Settings
2. Người dùng chọn Light hoặc Dark
3. Hệ thống toggle `html.dark` class
4. Hệ thống lưu preference vào localStorage

---

### UC-14: Chuyển đổi Ngôn ngữ

| Field | Description |
|-------|-------------|
| **UC ID** | UC-14 |
| **Actor** | Student |
| **Trigger** | Chọn ngôn ngữ trong Settings hoặc Topbar |
| **Precondition** | Đã đăng nhập |

**Main Flow:**
1. Người dùng chọn Tiếng Việt hoặc English
2. Hệ thống cập nhật language context
3. Toàn bộ UI re-render với ngôn ngữ mới
4. Hệ thống lưu preference vào localStorage

---

## 3.4. User Flow Diagrams

### 3.4.1. Authentication Flow

```
[Landing Page]
     │
     ├─[Login]───────────────────[Register]
     │       │                        │
     │       ▼                        ▼
     │  [Login Form]           [Register Form]
     │       │                        │
     │       ├─[Valid]──▶ [Dashboard]
     │       │                   │
     │       │                   │
     │       └─[Invalid]──▶ [Error Toast]
     │                            │
     └─[Get Started]──────────────┘
```

### 3.4.2. Project Management Flow

```
[Dashboard] ──[Select Project]──▶ [Project Overview]
                                          │
                    ┌─────────────────────┼─────────────────────┐
                    │                     │                     │
              [Tasks Board]         [Documents]           [Chat]
                    │                     │                     │
              ┌─────┴─────┐               │                     │
         [Kanban]   [Timeline]            │                     │
              │         │                 │                     │
         [Drag/Drop]  [Date View]    [Upload/Preview]     [Channel/DM]
              │                     │                     │
         [Task Modal]                  │                     │
              │                         │               [AI Chat]
         [Edit/Delete]                  │
                    │                     │
              [Add Task]            [Folder Tree]
                    │                     │
              [Fill Form]           [Navigate/Create]
                    │
              [Save Task]
```

### 3.4.3. Meeting Scheduling Flow

```
[Meetings Page] ──[Schedule Meeting]──▶ [Meeting Form]
                                             │
                              ┌──────────────┼──────────────┐
                              │              │              │
                        [Online]       [Offline]    [Validation Error]
                              │              │
                        [Meeting Link]  [Location]
                              │              │
                              └──────┬───────┘
                                     ▼
                            [Select Attendees]
                                     │
                               [Create Meeting]
                                     │
                                     ▼
                          [Attendee Notifications]
                                     │
                               [RSVP Responses]
```

### 3.4.4. Task Lifecycle Flow

```
[Add Task]
     │
     ▼
[BACKLOG]
     │
     ├─[Start Working]────────────────────┐
     ▼                                     │
[IN_PROGRESS]                              │
     │                                     │
     ├─[Pause]──▶ [ON_HOLD]                │
     │                                     │
     ├─[Submit for Review]──▶ [REVIEW]     │
     │                                     │
     │                          [Approved] │
     │                                     ▼
     │                              [DONE]
     │                                     │
     └─[Cancel]──▶ [CANCELLED] ◀───────────┘
```

---

## 3.5. Activity Diagrams

### 3.5.1. Task Creation Activity

```
[*] ──▶ Enter Task Details
         │
         ├──▶ Title = ""?
         │    YES ──▶ [Validation Error]
         │
         ├──▶ Description = ""?
         │    YES ──▶ [OK — optional field]
         │
         ├──▶ Assignee selected?
         │    NO ──▶ [Warning — no assignee]
         │
         ├──▶ Priority selected?
         │    NO ──▶ [Default MEDIUM]
         │
         ├──▶ Deadline in past?
         │    YES ──▶ [Warning but allow]
         │
         ▼
    [Save Task]
         │
         ├──▶ Success ──▶ [Task added to BACKLOG] ──▶ [*]
         │
         └──▶ Error ──▶ [Toast Error] ──▶ [*]
```

### 3.5.2. Document Upload Activity

```
[*] ──▶ Click Upload Button
         │
         ▼
    [Select File]
         │
         ├──▶ No file selected ──▶ [Cancel] ──▶ [*]
         │
         ├──▶ File size > 10MB?
         │    YES ──▶ [Error: File too large] ──▶ [*]
         │
         └──▶ File selected
              │
              ▼
         [Detect File Type]
              │
              ▼
         [Create Document Record]
              │
              ▼
         [Add to Document List]
              │
              ├──▶ DOCX/PDF/IMG ──▶ [Enable Preview Button]
              │
              └──▶ Other ──▶ [Show Info Only]
                   │
                   ▼
              [*]
```

---

## 3.6. Page-to-Route Mapping

| Page | Route | Access |
|------|-------|--------|
| Landing Page | `/` | Public |
| Login | `/login` | Guest only |
| Register | `/register` | Guest only |
| Dashboard | `/app` | Protected |
| Profile | `/app/profile` | Protected |
| Settings | `/app/settings` | Protected |
| Project List | `/app/projects` | Protected |
| Project Overview | `/app/projects/:projectId` | Protected |
| Tasks | `/app/projects/:projectId/tasks` | Protected |
| Documents | `/app/projects/:projectId/documents` | Protected |
| Members | `/app/projects/:projectId/members` | Protected |
| Meetings | `/app/projects/:projectId/meetings` | Protected |
| Chat | `/app/projects/:projectId/chat` | Protected |
| Performance | `/app/projects/:projectId/performance` | Protected |
