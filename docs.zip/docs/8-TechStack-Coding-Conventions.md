# 8. Tech Stack & Coding Conventions
## Development Standards for EZProject

> **Project:** EZProject
> **Version:** 1.0
> **Date:** May 2026

---

## 8.1. Tech Stack Summary

### 8.1.1. Current Stack (Frontend)

| Category | Technology | Version | Purpose |
|----------|-----------|---------|---------|
| **Framework** | React | 19.x | UI Library |
| **Language** | TypeScript | 5.9.x | Type safety |
| **Build Tool** | Vite | 7.x | Fast dev server & bundler |
| **Routing** | React Router | 7.x | Client-side routing |
| **Styling** | Tailwind CSS | 4.x | Utility-first CSS |
| **Icons** | Lucide React | 0.577.x | Consistent icon set |
| **PDF Viewer** | pdfjs-dist | 5.5.x | In-browser PDF rendering |
| **DOCX Viewer** | docx-preview | 0.3.x | In-browser DOCX rendering |
| **Linting** | ESLint | 9.x | Code quality |
| **Type Check** | TypeScript | 5.9.x | Compile-time checking |

### 8.1.2. Future Stack (Backend — Phase 2)

| Category | Technology | Notes |
|----------|-----------|-------|
| **Runtime** | Node.js 20+ | LTS |
| **Framework** | NestJS hoặc Express | REST API |
| **ORM** | Prisma hoặc Drizzle | Type-safe DB access |
| **Database** | PostgreSQL 15+ | Primary data store |
| **Cache** | Redis 7+ | Sessions, caching |
| **File Storage** | AWS S3 / MinIO | Document storage |
| **Auth** | JWT (access + refresh) | Stateless auth |
| **Real-time** | Socket.io | Chat |
| **Email** | SendGrid / AWS SES | Notifications |
| **Container** | Docker | Deployment |
| **CI/CD** | GitHub Actions | Automation |

---

## 8.2. Project Structure

```
Frontend/
├── src/
│   ├── components/              # Shared UI components
│   │   ├── ui/                  # Base components (Button, Card, Modal...)
│   │   │   ├── index.ts         # Barrel export
│   │   │   ├── Button.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Avatar.tsx
│   │   │   ├── EmptyState.tsx
│   │   │   ├── Skeleton.tsx
│   │   │   ├── Toast.tsx        # ToastProvider + useToast hook
│   │   │   ├── Drawer.tsx
│   │   │   ├── ProgressBar.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── RoleIcons.tsx
│   │   │   ├── MemberAvatar.tsx
│   │   │   └── ProjectMemberAvatar.tsx
│   │   │
│   │   └── layout/              # Layout components
│   │       ├── index.ts
│   │       ├── AppLayout.tsx    # Main app shell
│   │       ├── Sidebar.tsx      # Collapsible sidebar
│   │       ├── SidebarContext.tsx
│   │       ├── Topbar.tsx       # Top navigation bar
│   │       ├── NotificationDrawer.tsx
│   │       └── ProjectLayout.tsx
│   │
│   ├── features/                # Feature modules (self-contained)
│   │   ├── auth/
│   │   │   ├── index.ts
│   │   │   ├── AuthContext.tsx
│   │   │   ├── authService.ts
│   │   │   ├── LoginPage.tsx
│   │   │   ├── RegisterPage.tsx
│   │   │   ├── LoginForm.tsx
│   │   │   ├── BrandingPanel.tsx
│   │   │   ├── DemoAccountBox.tsx
│   │   │   ├── ProtectedRoute.tsx
│   │   │   └── GuestRoute.tsx
│   │   │
│   │   ├── dashboard/
│   │   │   ├── index.ts
│   │   │   ├── DashboardPage.tsx
│   │   │   └── ActivityItem.tsx
│   │   │
│   │   ├── projects/
│   │   ├── tasks/
│   │   ├── documents/
│   │   ├── members/
│   │   ├── meetings/
│   │   ├── chat/
│   │   ├── performance/
│   │   ├── profile/
│   │   └── landing/
│   │
│   ├── contexts/                # React contexts
│   │   ├── index.ts
│   │   ├── ThemeContext.tsx
│   │   └── LanguageContext.tsx
│   │
│   ├── i18n/                    # Internationalization
│   │   ├── index.ts
│   │   └── dict.ts              # Vietnamese + English dictionaries
│   │
│   ├── mocks/                   # Mock data (replaces API in Phase 1)
│   │   ├── index.ts
│   │   ├── members.ts
│   │   ├── projects.ts
│   │   ├── tasks.ts
│   │   ├── documents.ts
│   │   ├── meetings.ts
│   │   ├── chatRooms.ts
│   │   ├── chatMessages.ts
│   │   ├── activities.ts
│   │   ├── notifications.ts
│   │   ├── performance.ts
│   │   └── helpers.ts
│   │
│   ├── services/                # Data layer (Phase 1: mock; Phase 2: real API)
│   │   ├── index.ts
│   │   ├── taskService.ts
│   │   └── projectService.ts
│   │
│   ├── types/                   # TypeScript types
│   │   └── index.ts
│   │
│   ├── lib/                     # Utilities
│   │   └── greeting.ts
│   │
│   ├── App.tsx                  # Root with router
│   ├── main.tsx                 # Entry point
│   └── index.css                # Global styles + Tailwind
│
├── public/                      # Static assets
│   ├── favicon.svg
│   └── icons.svg
│
├── scripts/                     # Build/utility scripts
│   └── create-sample-docx.js
│
├── package.json
├── package-lock.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
├── tsconfig.app.json
├── tsconfig.node.json
├── eslint.config.js
└── .gitignore
```

---

## 8.3. Naming Conventions

### 8.3.1. Files

| Type | Convention | Example |
|------|-----------|---------|
| **Components** | PascalCase | `TaskBoard.tsx`, `MemberAvatar.tsx` |
| **Hooks/Contexts** | PascalCase + suffix | `ThemeContext.tsx`, `useToast.ts` |
| **Services** | camelCase + suffix | `taskService.ts`, `projectService.ts` |
| **Types/Interfaces** | PascalCase | `Project.ts`, `types/index.ts` |
| **Mock data** | camelCase + plural | `mockTasks.ts`, `mockMembers.ts` |
| **Utils** | camelCase | `greeting.ts`, `formatDate.ts` |
| **Config files** | kebab-case | `vite.config.ts`, `eslint.config.js` |

### 8.3.2. Variables & Functions

| Type | Convention | Example |
|------|-----------|---------|
| **Variables** | camelCase | `projectList`, `isLoading` |
| **Functions** | camelCase, verb prefix | `handleClick`, `fetchProjects` |
| **React components** | PascalCase | `TaskCard`, `ProjectOverview` |
| **Constants** | SCREAMING_SNAKE_CASE | `MAX_FILE_SIZE`, `API_BASE_URL` |
| **Boolean variables** | is/has/can prefix | `isActive`, `hasPermission` |
| **Event handlers** | handle prefix | `handleSubmit`, `handleChange` |
| **Async functions** | async prefix (optional) | `fetchUserData` |

### 8.3.3. Types & Interfaces

```typescript
// Interface for data objects
interface Project {
  id: string;
  name: string;
  status: ProjectStatus;
}

// Type alias for union types
type TaskStatus = 'BACKLOG' | 'IN_PROGRESS' | 'REVIEW' | 'DONE' | 'ON_HOLD' | 'CANCELLED';
type TaskPriority = 'LOW' | 'MEDIUM' | 'HIGH';

// Type for component props
type ButtonProps = {
  variant: 'primary' | 'secondary' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
};
```

---

## 8.4. Component Patterns

### 8.4.1. Component Structure

```tsx
// Good: Self-contained component with co-located types
import { useState } from 'react';
import { Button } from '@/components/ui';
import type { Task } from '@/types';

interface TaskCardProps {
  task: Task;
  onStatusChange: (id: string, status: string) => void;
}

export function TaskCard({ task, onStatusChange }: TaskCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="ez-card" onClick={() => setIsExpanded(!isExpanded)}>
      <h3>{task.title}</h3>
      {/* ... */}
    </div>
  );
}
```

### 8.4.2. Barrel Export Pattern

```typescript
// features/tasks/index.ts
export { default as TaskBoard } from './TaskBoard';
export { default as TaskTimeline } from './TaskTimeline';
export { default as TaskColumn } from './TaskColumn';
export { default as TaskCard } from './TaskCard';
export { default as TaskModal } from './TaskModal';
export { default as AddTaskModal } from './AddTaskModal';
```

### 8.4.3. Feature Module Pattern

```
features/[feature-name]/
├── index.ts           (barrel exports)
├── [Feature]Page.tsx (main page component)
├── [Feature]Card.tsx (display card)
├── [Feature]Modal.tsx (detail/create modal)
└── [Feature]Form.tsx (form components, if complex)
```

---

## 8.5. Git Flow

### 8.5.1. Branch Naming

| Type | Format | Example |
|------|--------|---------|
| **Feature** | `feature/<ticket-id>-short-description` | `feature/PROJ-42-task-board` |
| **Bug Fix** | `fix/<ticket-id>-short-description` | `fix/PROJ-55-login-redirect` |
| **Hotfix** | `hotfix/<ticket-id>-short-description` | `hotfix/PROJ-60-security-patch` |
| **Chore** | `chore/short-description` | `chore/update-dependencies` |
| **Refactor** | `refactor/short-description` | `refactor/extract-modal-component` |

### 8.5.2. Commit Convention

Format: `<type>(<scope>): <description>`

```
feat(auth): add login with demo account
feat(tasks): implement Kanban drag-and-drop
fix(chat): resolve message not showing on channel switch
refactor(ui): extract Button as reusable component
chore(deps): upgrade React to 19.2.4
docs(readme): update installation instructions
style(css): adjust card hover shadow
perf(tasks): memoize TaskCard to prevent re-renders
test(tasks): add unit tests for TaskBoard
```

### 8.5.3. Commit Types

| Type | Description |
|------|-------------|
| **feat** | New feature |
| **fix** | Bug fix |
| **refactor** | Code change that doesn't fix a bug or add feature |
| **chore** | Maintenance tasks (deps, configs) |
| **docs** | Documentation changes |
| **style** | Formatting, white-space (no code change) |
| **perf** | Performance improvements |
| **test** | Adding or updating tests |
| **build** | Build system or CI/CD changes |

### 8.5.4. Pull Request Process

```
1. Create branch from main
2. Make changes + commit (conventional commits)
3. Push branch
4. Open PR with template:
   - Title: [PROJ-##] Brief description
   - Description: What changed, Why, How to test
   - Labels: feature / bug / refactor / etc.
5. Request review from team
6. Address feedback
7. Squash and merge
```

---

## 8.6. Code Style Guidelines

### 8.6.1. React Best Practices

```tsx
// Good: Destructuring props
function TaskCard({ task, onStatusChange }: TaskCardProps) {
  // ...
}

// Good: Early returns
function TaskBoard({ tasks }: TaskBoardProps) {
  if (!tasks.length) {
    return <EmptyState message="No tasks yet" />;
  }
  return <div>{tasks.map(task => <TaskCard key={task.id} task={task} />)}</div>;
}

// Good: Composition over prop drilling
function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <Router />
      </ThemeProvider>
    </AuthProvider>
  );
}

// Good: useMemo for expensive computations
const sortedTasks = useMemo(
  () => [...tasks].sort((a, b) => new Date(a.deadline) - new Date(b.deadline)),
  [tasks]
);

// Good: useCallback for event handlers passed as props
const handleTaskClick = useCallback((taskId: string) => {
  setSelectedTask(taskId);
}, []);
```

### 8.6.2. CSS / Tailwind Guidelines

```tsx
// Good: Extract repeated classes to component
<div className="ez-card hover:shadow-md transition-shadow">
  {/* content */}
</div>

// Good: Responsive design
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

// Good: Dark mode with class strategy
<div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100">

// Avoid: Inline styles (except dynamic values)
<div style={{ width: `${progress}%` }}>  // OK for dynamic
<div style={{ marginTop: '16px' }}>     // Avoid
```

### 8.6.3. Import Order

```typescript
// 1. React / Framework
import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';

// 2. Third-party libraries
import { Button } from '@/components/ui';
import { FileText } from 'lucide-react';

// 3. Project modules (absolute paths)
import { mockProjects } from '@/mocks/projects';
import type { Project } from '@/types';
import { useAuth } from '@/features/auth';

// 4. Relative imports
import { TaskCard } from './TaskCard';

// 5. Types/interfaces in same file
```

### 8.6.4. TypeScript Guidelines

```typescript
// Good: Explicit types for props
interface ButtonProps {
  label: string;
  onClick: () => void;
  disabled?: boolean;
}

// Good: Type vs Interface
// - Use interface for object shapes (extendable)
// - Use type for unions, primitives, aliases

type TaskStatus = 'BACKLOG' | 'IN_PROGRESS' | 'DONE';
interface Task {
  id: string;
  status: TaskStatus;
}

// Good: Generic types
function getItem<T>(list: T[], id: string): T | undefined {
  return list.find(item => (item as { id: string }).id === id);
}

// Good: Optional chaining + nullish coalescing
const taskName = task?.title ?? 'Untitled';
```

---

## 8.7. Testing Strategy

### 8.7.1. Testing Pyramid

```
         ▲
        /E\        E2E Tests (Playwright)
       /2E \       - Critical user flows
      /─────\      - Login, create project, task workflow
     / I  I  \     Integration Tests
    /───────  \    - Component interactions
   /  U  U  U  \   Unit Tests
  /─────────────\  - Pure functions, hooks, services
 ▲───────────────▲────────────────────────▶
  Unit     Integration   E2E
  (many)      (some)    (few)
```

### 8.7.2. What to Test

| Layer | What to Test | Tool |
|-------|-------------|------|
| **Unit** | Utility functions, hook logic, service methods | Vitest |
| **Component** | Render output, user interactions, state changes | Vitest + Testing Library |
| **Integration** | Multi-component flows, context providers | Vitest + Testing Library |
| **E2E** | Full user flows across pages | Playwright |

### 8.7.3. Test File Location

```
src/
├── lib/
│   ├── greeting.ts
│   └── greeting.test.ts
│
src/
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   └── Button.test.tsx
│
src/
├── features/
│   ├── tasks/
│   │   ├── TaskBoard.tsx
│   │   └── TaskBoard.test.tsx
```

---

## 8.8. ESLint & Prettier Configuration

### 8.8.1. ESLint Rules (`.eslint.config.js`)

```javascript
import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';

export default tseslint.config(
  { ignores: ['dist', 'node_modules'] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    plugins: { 'react-hooks': reactHooks, 'react-refresh': reactRefresh },
    rules: {
      ...reactHooks.configs.recommended.rules,
      'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      '@typescript-eslint/no-explicit-any': 'warn',
      'no-console': ['warn', { allow: ['warn', 'error'] }],
    },
  }
);
```

### 8.8.2. Prettier Configuration

```json
{
  "semi": true,
  "singleQuote": true,
  "tabWidth": 2,
  "trailingComma": "es5",
  "printWidth": 100,
  "bracketSpacing": true,
  "arrowParens": "always",
  "endOfLine": "lf"
}
```

---

## 8.9. Development Workflow

### 8.9.1. Setup

```bash
# Clone repository
git clone <repo-url>
cd Frontend

# Install dependencies
npm install

# Start development server
npm run dev

# Type checking
npm run type-check

# Linting
npm run lint

# Build for production
npm run build
```

### 8.9.2. Daily Workflow

```
1. git checkout main && git pull
2. git checkout -b feature/PROJ-##
3. Write code + commit (conventional commits)
4. npm run type-check && npm run lint  # Local checks
5. Push branch
6. Open PR
7. After merge: git checkout main && git pull
```

### 8.9.3. Pre-commit Hook (Husky — Phase 2)

```bash
# Install Husky
npx husky install

# Add pre-commit hook
npx husky add .husky/pre-commit "npm run type-check && npm run lint"
```
